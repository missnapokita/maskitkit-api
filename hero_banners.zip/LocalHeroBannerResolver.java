package com.iandev.masterkit;

import android.app.Activity;
import android.graphics.BitmapFactory;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Locale;

/**
 * Local hero landscape banner resolver backed by assets/hero_banners.json.
 *
 * The JSON stores candidate MLBB Wiki/Fandom URLs. Each URL is validated
 * before use. Only images with a landscape aspect ratio are accepted.
 *
 * Existing MasterKit backdrop/image remains the fallback when no valid
 * landscape image is found.
 */
public final class LocalHeroBannerResolver {

	private static final HashMap<String, JSONArray> CANDIDATES =
			new HashMap<>();

	private static final HashMap<String, String> RESOLVED =
			new HashMap<>();

	private static final HashMap<String, Boolean> FAILED =
			new HashMap<>();

	private static boolean loaded;

	private LocalHeroBannerResolver() {
	}

	public static String getBannerBlocking(
			Activity activity,
			String heroName) {

		if (activity == null) {
			return "";
		}

		String key =
				normalize(heroName);

		if (key.isEmpty()) {
			return "";
		}

		ensureLoaded(activity);

		synchronized (LocalHeroBannerResolver.class) {

			String cached =
					RESOLVED.get(key);

			if (cached != null) {
				return cached;
			}

			Boolean failed =
					FAILED.get(key);

			if (failed != null && failed) {
				return "";
			}
		}

		JSONArray urls =
				CANDIDATES.get(key);

		if (urls == null) {

			synchronized (LocalHeroBannerResolver.class) {
				FAILED.put(key, true);
			}

			return "";
		}

		for (int i = 0; i < urls.length(); i++) {

			String candidate =
					urls.optString(i, "").trim();

			if (candidate.isEmpty()) {
				continue;
			}

			if (isLandscapeImage(candidate)) {

				synchronized (LocalHeroBannerResolver.class) {
					RESOLVED.put(key, candidate);
				}

				return candidate;
			}
		}

		synchronized (LocalHeroBannerResolver.class) {
			FAILED.put(key, true);
		}

		return "";
	}

	private static synchronized void ensureLoaded(
			Activity activity) {

		if (loaded) {
			return;
		}

		loaded = true;

		try {
			InputStream inputStream =
					activity.getAssets()
							.open("hero_banners.json");

			JSONObject root =
					new JSONObject(
							readStream(inputStream)
					);

			JSONArray data =
					root.optJSONArray("data");

			if (data == null) {
				return;
			}

			for (int i = 0; i < data.length(); i++) {

				JSONObject item =
						data.optJSONObject(i);

				if (item == null) {
					continue;
				}

				String name =
						item.optString("name", "");

				JSONArray candidates =
						item.optJSONArray("candidates");

				String key =
						normalize(name);

				if (!key.isEmpty()
						&& candidates != null
						&& candidates.length() > 0) {

					CANDIDATES.put(key, candidates);
				}
			}

		} catch (Exception ignored) {
		}
	}

	private static boolean isLandscapeImage(
			String imageUrl) {

		HttpURLConnection connection = null;
		InputStream inputStream = null;

		try {
			connection =
					(HttpURLConnection)
							new URL(imageUrl).openConnection();

			connection.setRequestMethod("GET");
			connection.setConnectTimeout(5000);
			connection.setReadTimeout(8000);
			connection.setInstanceFollowRedirects(true);
			connection.setUseCaches(true);

			connection.setRequestProperty(
					"User-Agent",
					"Mozilla/5.0 (Android; MasterKit)"
			);

			int responseCode =
					connection.getResponseCode();

			if (responseCode < 200
					|| responseCode >= 300) {
				return false;
			}

			String contentType =
					connection.getContentType();

			if (contentType != null
					&& !contentType.toLowerCase(Locale.US)
					.startsWith("image/")) {
				return false;
			}

			inputStream =
					connection.getInputStream();

			BitmapFactory.Options options =
					new BitmapFactory.Options();

			options.inJustDecodeBounds = true;

			BitmapFactory.decodeStream(
					inputStream,
					null,
					options
			);

			if (options.outWidth <= 0
					|| options.outHeight <= 0) {
				return false;
			}

			float ratio =
					(float) options.outWidth
							/ (float) options.outHeight;

			/*
			 * Accept normal landscape and banner-like artwork.
			 * Portrait and square hero icons are rejected.
			 */
			return ratio >= 1.35f;

		} catch (Exception ignored) {
			return false;

		} finally {

			try {
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (Exception ignored) {
			}

			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private static String readStream(
			InputStream inputStream)
			throws Exception {

		BufferedReader reader =
				new BufferedReader(
						new InputStreamReader(
								inputStream,
								"UTF-8"
						)
				);

		StringBuilder result =
				new StringBuilder();

		String line;

		while ((line = reader.readLine()) != null) {
			result.append(line);
		}

		reader.close();

		return result.toString();
	}

	private static String normalize(
			String value) {

		return value == null
				? ""
				: value.toLowerCase(Locale.US)
						.replace("&", "and")
						.replace("’", "")
						.replace("'", "")
						.replace(".", "")
						.replace("-", "")
						.replace("_", "")
						.replace(" ", "")
						.trim();
	}
}
