Replace only your current <FrameLayout android:id="@+id/frame_hero_banner"> ... </FrameLayout> block with frame_hero_banner_fixed.xml.

Fix applied:
- TopCropImageView is self-closing and has no child views.
- imageview4 is now a sibling inside frame_hero_banner.
- imageview4 appears above the gradient because it is declared after the gradient.
- linear_hero_information stays at the bottom.
