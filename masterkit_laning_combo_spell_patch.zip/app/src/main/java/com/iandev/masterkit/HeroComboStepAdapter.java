package com.iandev.masterkit;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HeroComboStepAdapter
		extends RecyclerView.Adapter<HeroComboStepAdapter.Holder> {

	private final Activity activity;
	private final ArrayList<HeroComboStepItem> list;

	public HeroComboStepAdapter(
			Activity activity,
			ArrayList<HeroComboStepItem> list) {

		this.activity = activity;
		this.list = list;
	}

	@NonNull
	@Override
	public Holder onCreateViewHolder(
			@NonNull ViewGroup parent,
			int viewType) {

		View view = LayoutInflater
				.from(activity)
				.inflate(
						R.layout.hero_combo_step_item,
						parent,
						false
				);

		return new Holder(view);
	}

	@Override
	public void onBindViewHolder(
			@NonNull Holder holder,
			int position) {

		HeroComboStepItem item =
				list.get(position);

		String label = item.label;

		if (label == null
				|| label.trim().length() == 0) {

			label = item.step > 0
					? "Step " + item.step
					: "Step";
		}

		holder.label.setText(label);

		SimpleImageLoader.load(
				item.image,
				holder.image,
				R.drawable.des
		);
	}

	@Override
	public int getItemCount() {
		return list == null ? 0 : list.size();
	}

	public static class Holder
			extends RecyclerView.ViewHolder {

		ImageView image;
		TextView label;

		public Holder(View itemView) {
			super(itemView);

			image = itemView.findViewById(
					R.id.imageview_combo_step
			);

			label = itemView.findViewById(
					R.id.textview_combo_step
			);
		}
	}
}
