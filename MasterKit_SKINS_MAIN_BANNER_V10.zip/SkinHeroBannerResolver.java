package com.iandev.masterkit;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Main Hero Guide banner resolver.
 *
 * Source:
 * https://raw.githubusercontent.com/missnapokita/masterkiter/refs/heads/main/skins.json
 *
 * Only base hero entries are indexed:
 * - aamon      accepted
 * - aamon01    rejected
 * - aamon02    rejected
 *
 * The resolver supports several possible field names so minor JSON schema
 * differences do not break the app.
 */
public final class SkinHeroBannerResolver {

	private static final String SKINS_URL =
			"https://raw.githubusercontent.com/missnapokita/masterkiter/refs/heads/main/skins.json";

	private static final HashMap<String, String> BY_ID =
			new HashMap<>();

	private static final HashMap<String, String> BY_NAME =
			new HashMap<>();

	private static final Pattern NUMBERED_SKIN_ID =
			Pattern.compile(".*\\d+$");

	private static boolean loaded;
	private static boolean loadingFailed;

	private SkinHeroBannerResolver() {
	}

	public static String getBaseSkinImageBlocking(
			String heroId,
			String heroName) {

		ensureLoaded();

		String idKey =
				normalize(heroId);

		String nameKey =
				normalize(heroName);

		String image =
				BY_ID.get(idKey);

		if (image != null && !image.isEmpty()) {
			return image;
		}

		image = BY_NAME.get(nameKey);

		return image == null ? "" : image;
	}

	private static synchronized void ensureLoaded() {

		if (loaded || loadingFailed) {
			return;
		}

		HttpURLConnection connection = null;

		try {
			connection =
					(HttpURLConnection)
							new URL(SKINS_URL)
									.openConnection();

			connection.setRequestMethod("GET");
			connection.setConnectTimeout(10000);
			connection.setReadTimeout(20000);
			connection.setUseCaches(true);

			connection.setRequestProperty(
					"Accept",
					"application/json"
			);

			connection.setRequestProperty(
					"User-Agent",
					"MasterKit-Android"
			);

			int code =
					connection.getResponseCode();

			if (code < 200 || code >= 300) {
				loadingFailed = true;
				return;
			}

			String response =
					readStream(
							connection.getInputStream()
					);

			Object root =
					new JSONTokener(response)
							.nextValue();

			indexRoot(root);

			loaded = true;

		} catch (Exception ignored) {
			loadingFailed = true;

		} finally {

			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private static void indexRoot(
			Object root) {

		if (root instanceof JSONArray) {

			indexArray((JSONArray) root);
			return;
		}

		if (!(root instanceof JSONObject)) {
			return;
		}

		JSONObject object =
				(JSONObject) root;

		/*
		 * Common wrapper keys.
		 */
		String[] possibleArrays = {
				"data",
				"skins",
				"heroes",
				"results"
		};

		for (String key : possibleArrays) {

			JSONArray array =
					object.optJSONArray(key);

			if (array != null) {
				indexArray(array);
				return;
			}
		}

		/*
		 * Last-resort recursive scan for an array of skin objects.
		 */
		Iterator<String> keys =
				object.keys();

		while (keys.hasNext()) {

			Object value =
					object.opt(keys.next());

			if (value instanceof JSONArray) {
				indexArray((JSONArray) value);
			}
		}
	}

	private static void indexArray(
			JSONArray array) {

		for (int i = 0; i < array.length(); i++) {

			JSONObject item =
					array.optJSONObject(i);

			if (item == null) {
				continue;
			}

			String rawId =
					firstText(
							item,
							"id",
							"hero_id",
							"slug",
							"key"
					);

			/*
			 * Include base hero entries only.
			 * Numeric suffixes represent additional skins.
			 */
			if (!rawId.isEmpty() &&
				NUMBERED_SKIN_ID.matcher(
						rawId.toLowerCase(Locale.US)
				).matches()) {
				continue;
			}

			String heroName =
					firstText(
							item,
							"hero_name",
							"heroName",
							"hero",
							"name"
					);

			String skinName =
					firstText(
							item,
							"skin_name",
							"skinName",
							"skin"
					);

			/*
			 * If an explicit skin name exists, prefer base/default entries.
			 */
			if (!skinName.isEmpty() &&
				!isBaseSkinName(skinName)) {

				/*
				 * Keep the item only when its ID clearly has no skin suffix.
				 * This supports files where the base skin has a named title.
				 */
				if (rawId.isEmpty()) {
					continue;
				}
			}

			String image =
					firstHttp(
							item,
							"image",
							"portrait",
							"cover",
							"art",
							"skin_image",
							"skinImage",
							"url"
					);

			if (image.isEmpty()) {
				continue;
			}

			String idKey =
					normalize(rawId);

			String nameKey =
					normalize(heroName);

			if (!idKey.isEmpty() &&
				!BY_ID.containsKey(idKey)) {
				BY_ID.put(idKey, image);
			}

			if (!nameKey.isEmpty() &&
				!BY_NAME.containsKey(nameKey)) {
				BY_NAME.put(nameKey, image);
			}
		}
	}

	private static boolean isBaseSkinName(
			String value) {

		String key =
				normalize(value);

		return key.isEmpty()
				|| key.equals("default")
				|| key.equals("basic")
				|| key.equals("normal")
				|| key.equals("original")
				|| key.equals("base");
	}

	private static String firstText(
			JSONObject object,
			String... keys) {

		for (String key : keys) {

			String value =
					object.optString(
							key,
							""
					).trim();

			if (!value.isEmpty() &&
				!"null".equalsIgnoreCase(value)) {
				return value;
			}
		}

		return "";
	}

	private static String firstHttp(
			JSONObject object,
			String... keys) {

		for (String key : keys) {

			String value =
					object.optString(
							key,
							""
					).trim();

			if (isHttp(value)) {
				return value;
			}
		}

		return "";
	}

	private static boolean isHttp(
			String value) {

		String clean =
				value == null
						? ""
						: value.toLowerCase(Locale.US)
								.trim();

		return clean.startsWith("https://")
				|| clean.startsWith("http://");
	}

	private static String normalize(
			String value) {

		return value == null
				? ""
				: value.toLowerCase(Locale.US)
						.replace("&", "and")
						.replace("’", "")
						.replace("'", "")
						.replace(".", "")
						.replace("-", "")
						.replace("_", "")
						.replace(" ", "")
						.trim();
	}

	private static String readStream(
			InputStream inputStream)
			throws Exception {

		BufferedReader reader =
				new BufferedReader(
						new InputStreamReader(
								inputStream,
								"UTF-8"
						)
				);

		StringBuilder result =
				new StringBuilder();

		String line;

		while ((line = reader.readLine()) != null) {
			result.append(line);
		}

		reader.close();

		return result.toString();
	}
}
