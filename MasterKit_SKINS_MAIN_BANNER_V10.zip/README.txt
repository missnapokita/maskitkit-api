MASTERKIT SKINS.JSON MAIN HERO BANNER V10

SOURCE
https://raw.githubusercontent.com/missnapokita/masterkiter/refs/heads/main/skins.json

INSTALL
1. Replace HeroGuideLoader.java.
2. Add SkinHeroBannerResolver.java.
3. Add TopCropImageView.java.
4. In heroguide.xml, replace ONLY the existing
   <ImageView android:id="@+id/imageview_hero_background" ... />
   with the tag inside heroguide_banner_snippet.xml.

BEHAVIOR
- Main hero header only uses the base hero entry from skins.json.
- Entries whose ID ends with digits (aamon01, aamon02, etc.) are ignored.
- Counter and Strong Against images are untouched.
- Current API backdrop is shown immediately as fallback.
- skins.json loads separately, so Hero Guide content is not blocked.
- TopCropImageView crops 9:16 art from the top so the hero head stays visible.
- skins.json is cached in memory for the rest of the app session.
