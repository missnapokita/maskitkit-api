package com.iandev.masterkit;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Locale;

public class HeroCounterAdapter
		extends RecyclerView.Adapter<HeroCounterAdapter.Holder> {

	private final Activity activity;
	private final ArrayList<HeroCounterItem> list;

	public HeroCounterAdapter(
			Activity activity,
			ArrayList<HeroCounterItem> list) {

		this.activity = activity;
		this.list = list;
	}

	@NonNull
	@Override
	public Holder onCreateViewHolder(
			@NonNull ViewGroup parent,
			int viewType) {

		View view = LayoutInflater
				.from(activity)
				.inflate(
						R.layout.hero_counter_item,
						parent,
						false
				);

		return new Holder(view);
	}

	@Override
	public void onBindViewHolder(
			@NonNull Holder holder,
			int position) {

		final HeroCounterItem item = list.get(position);

		holder.name.setText(
				item.name == null ? "" : item.name
		);

		StringBuilder meta = new StringBuilder();

		if (item.tier != null
				&& item.tier.trim().length() > 0) {

			meta.append("Tier ")
					.append(item.tier.trim());
		}

		if (item.role != null
				&& item.role.trim().length() > 0) {

			if (meta.length() > 0) {
				meta.append(" • ");
			}

			meta.append(item.role.trim());
		}

		holder.meta.setText(meta.toString());
		holder.meta.setVisibility(
				meta.length() > 0
						? View.VISIBLE
						: View.GONE
		);

		if (!Double.isNaN(item.winRate)) {

			holder.rate.setText(
					formatNumber(item.winRate) + "%"
			);

			holder.rate.setVisibility(View.VISIBLE);

		} else {

			holder.rate.setVisibility(View.GONE);
		}

		SimpleImageLoader.load(
				item.image,
				holder.image,
				R.drawable.des
		);

		holder.itemView.setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View view) {

						if (item.id == null
								|| item.id.trim().length() == 0) {
							return;
						}

						Intent intent = new Intent(
								activity,
								HeroguideActivity.class
						);

						intent.putExtra(
								"hero_id",
								item.id
						);

						intent.putExtra(
								"hero_name",
								item.name
						);

						activity.startActivity(intent);
					}
				}
		);
	}

	private String formatNumber(double value) {

		if (value == Math.floor(value)) {
			return String.valueOf((int) value);
		}

		return String.format(
				Locale.US,
				"%.2f",
				value
		).replaceAll("0+$", "")
				.replaceAll("\\.$", "");
	}

	@Override
	public int getItemCount() {
		return list == null ? 0 : list.size();
	}

	public static class Holder
			extends RecyclerView.ViewHolder {

		ImageView image;
		TextView name;
		TextView meta;
		TextView rate;

		public Holder(View itemView) {
			super(itemView);

			image = itemView.findViewById(
					R.id.imageview_counter
			);

			name = itemView.findViewById(
					R.id.textview_counter_name
			);

			meta = itemView.findViewById(
					R.id.textview_counter_meta
			);

			rate = itemView.findViewById(
					R.id.textview_counter_rate
			);
		}
	}
}
