package com.iandev.masterkit;

public class HeroCounterItem {

	public String id = "";
	public String name = "";
	public String image = "";
	public String role = "";
	public String tier = "";
	public double winRate = Double.NaN;
	public double delta = Double.NaN;
}
