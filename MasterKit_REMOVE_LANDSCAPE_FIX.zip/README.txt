REMOVE LANDSCAPE PATCH

1. Replace your current HeroGuideLoader.java with the included file.
2. Delete LocalHeroBannerResolver.java from your project.
3. Delete assets/hero_banners.json from your project.

This restores the fast loading version with:
- Wiki hero icons for counter/strong
- Local emblem images
- Local item images
- No landscape URL probing
