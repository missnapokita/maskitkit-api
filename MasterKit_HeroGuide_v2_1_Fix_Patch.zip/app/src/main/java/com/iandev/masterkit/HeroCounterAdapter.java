package com.iandev.masterkit;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Outline;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.ViewOutlineProvider;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Locale;

public class HeroCounterAdapter
		extends RecyclerView.Adapter<HeroCounterAdapter.Holder> {

	private static final String HERO_API =
			"https://maskitkit-api.vercel.app/api/hero?id=";

	private static final HashMap<String, String>
			PORTRAIT_CACHE = new HashMap<>();

	private final Activity activity;
	private final ArrayList<HeroCounterItem> list;

	public HeroCounterAdapter(
			Activity activity,
			ArrayList<HeroCounterItem> list) {

		this.activity = activity;
		this.list = list;
	}

	@NonNull
	@Override
	public Holder onCreateViewHolder(
			@NonNull ViewGroup parent,
			int viewType) {

		View view = LayoutInflater
				.from(activity)
				.inflate(
						R.layout.hero_counter_item,
						parent,
						false
				);

		return new Holder(view);
	}

	@Override
	public void onBindViewHolder(
			@NonNull Holder holder,
			int position) {

		final HeroCounterItem item = list.get(position);

		holder.name.setText(
				item.name == null ? "" : item.name
		);

		StringBuilder meta = new StringBuilder();

		if (item.tier != null
				&& item.tier.trim().length() > 0) {

			meta.append("Tier ")
					.append(item.tier.trim());
		}

		if (item.role != null
				&& item.role.trim().length() > 0) {

			if (meta.length() > 0) {
				meta.append(" • ");
			}

			meta.append(item.role.trim());
		}

		holder.meta.setText(meta.toString());
		holder.meta.setVisibility(
				meta.length() > 0
						? View.VISIBLE
						: View.GONE
		);

		if (!Double.isNaN(item.winRate)) {

			holder.rate.setText(
					formatNumber(item.winRate) + "%"
			);

			holder.rate.setVisibility(View.VISIBLE);

		} else {

			holder.rate.setVisibility(View.GONE);
		}

		applyCircle(holder.image);

		String cachedPortrait = "";

		synchronized (PORTRAIT_CACHE) {

			if (item.id != null) {

				String value =
						PORTRAIT_CACHE.get(
								item.id.trim()
						);

				if (value != null) {
					cachedPortrait = value;
				}
			}
		}

		String initialImage =
				cachedPortrait.length() > 0
						? cachedPortrait
						: item.icon != null
						&& item.icon.trim().length() > 0
								? item.icon
								: item.image;

		SimpleImageLoader.load(
				initialImage,
				holder.image,
				R.drawable.des
		);

		/*
		 * Counter API currently returns wide artwork.
		 * Kunin ang backdrop ng mismong hero guide para
		 * head/portrait icon ang lumabas dito.
		 */
		loadPortrait(
				holder,
				item
		);

		holder.itemView.setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View view) {

						if (item.id == null
								|| item.id.trim().length() == 0) {
							return;
						}

						Intent intent = new Intent(
								activity,
								HeroguideActivity.class
						);

						intent.putExtra(
								"hero_id",
								item.id
						);

						intent.putExtra(
								"hero_name",
								item.name
						);

						activity.startActivity(intent);
					}
				}
		);
	}

	private void loadPortrait(
			final Holder holder,
			final HeroCounterItem item) {

		if (holder == null
				|| item == null
				|| item.id == null
				|| item.id.trim().length() == 0) {
			return;
		}

		final String heroId =
				item.id.trim().toLowerCase();

		synchronized (PORTRAIT_CACHE) {

			String cached =
					PORTRAIT_CACHE.get(heroId);

			if (cached != null
					&& cached.trim().length() > 0) {

				SimpleImageLoader.load(
						cached,
						holder.image,
						R.drawable.des
				);

				return;
			}
		}

		final int adapterPosition =
				holder.getBindingAdapterPosition();

		holder.image.setTag(
				R.id.imageview_counter_hero,
				heroId
		);

		new AsyncTask<Void, Void, String>() {

			@Override
			protected String doInBackground(
					Void... ignored) {

				HttpURLConnection connection = null;
				InputStream inputStream = null;
				BufferedReader reader = null;

				try {

					URL url =
							new URL(
									HERO_API +
									java.net.URLEncoder.encode(
											heroId,
											"UTF-8"
									)
							);

					connection =
							(HttpURLConnection)
									url.openConnection();

					connection.setRequestMethod("GET");
					connection.setConnectTimeout(10000);
					connection.setReadTimeout(12000);
					connection.setUseCaches(true);
					connection.setRequestProperty(
							"User-Agent",
							"MasterKit/1.0"
					);

					int responseCode =
							connection.getResponseCode();

					if (responseCode < 200
							|| responseCode >= 300) {
						return "";
					}

					inputStream =
							connection.getInputStream();

					reader =
							new BufferedReader(
									new InputStreamReader(
											inputStream,
											"UTF-8"
									)
							);

					StringBuilder result =
							new StringBuilder();

					String line;

					while ((line =
							reader.readLine()) != null) {
						result.append(line);
					}

					JSONObject root =
							new JSONObject(
									result.toString()
							);

					JSONObject hero =
							root.optJSONObject("hero");

					if (hero == null) {
						return "";
					}

					/*
					 * backdrop = close-up/head portrait.
					 * image = wide artwork fallback.
					 */
					String portrait =
							hero.optString("backdrop", "")
									.trim();

					if (portrait.length() == 0) {
						portrait =
								hero.optString(
										"image",
										""
								).trim();
					}

					return portrait;

				} catch (Exception ignoredError) {

					return "";

				} finally {

					try {
						if (reader != null) {
							reader.close();
						}
					} catch (Exception ignoredClose) {
					}

					try {
						if (inputStream != null) {
							inputStream.close();
						}
					} catch (Exception ignoredClose) {
					}

					if (connection != null) {
						connection.disconnect();
					}
				}
			}

			@Override
			protected void onPostExecute(
					String portrait) {

				if (portrait == null
						|| portrait.trim().length() == 0
						|| activity == null
						|| activity.isFinishing()) {
					return;
				}

				synchronized (PORTRAIT_CACHE) {
					PORTRAIT_CACHE.put(
							heroId,
							portrait
					);
				}

				Object tag =
						holder.image.getTag(
								R.id.imageview_counter_hero
						);

				if (tag == null
						|| !heroId.equals(
								String.valueOf(tag)
						)) {
					return;
				}

				SimpleImageLoader.load(
						portrait,
						holder.image,
						R.drawable.des
				);
			}

		}.execute();
	}

	private void applyCircle(final ImageView imageView) {

		if (imageView == null) {
			return;
		}

		imageView.setScaleType(
				ImageView.ScaleType.CENTER_CROP
		);

		if (android.os.Build.VERSION.SDK_INT >= 21) {

			imageView.setClipToOutline(true);

			imageView.setOutlineProvider(
					new ViewOutlineProvider() {
						@Override
						public void getOutline(
								View view,
								Outline outline) {

							outline.setOval(
									0,
									0,
									view.getWidth(),
									view.getHeight()
							);
						}
					}
			);
		}
	}

	private String formatNumber(double value) {

		if (value == Math.floor(value)) {
			return String.valueOf((int) value);
		}

		return String.format(
				Locale.US,
				"%.2f",
				value
		).replaceAll("0+$", "")
				.replaceAll("\\.$", "");
	}

	@Override
	public int getItemCount() {
		return list == null ? 0 : list.size();
	}

	public static class Holder
			extends RecyclerView.ViewHolder {

		ImageView image;
		TextView name;
		TextView meta;
		TextView rate;

		public Holder(View itemView) {
			super(itemView);

			image = itemView.findViewById(
					R.id.imageview_counter
			);

			name = itemView.findViewById(
					R.id.textview_counter_name
			);

			meta = itemView.findViewById(
					R.id.textview_counter_meta
			);

			rate = itemView.findViewById(
					R.id.textview_counter_rate
			);
		}
	}
}
