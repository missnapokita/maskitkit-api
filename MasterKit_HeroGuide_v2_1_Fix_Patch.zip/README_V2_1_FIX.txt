MASTERKIT HERO GUIDE V2.1 FIX

Fixes:
1. Main hero banner now uses hero.image first (wide artwork).
2. Counter Heroes and Strong Against fetch each hero's backdrop
   from /api/hero?id=... and use it as the close-up portrait.
3. Role parser supports:
   - Fighter / Assassin
   - Fighter, Assassin
   - roles: ["Fighter", "Assassin"]
   - arrays containing role objects
4. Duplicate roles are removed.
5. No new code is required in HeroguideActivity onCreate.

Keep:
HeroGuideLoader.apply(this);

Note:
Counter portraits make one API request per hero the first time.
A memory cache prevents repeat requests during the same app session.
