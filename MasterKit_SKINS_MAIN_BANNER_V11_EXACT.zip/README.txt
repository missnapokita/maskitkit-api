MASTERKIT SKINS.JSON MAIN HERO BANNER V11

This version fixes the parser using the REAL skins.json structure.

REAL STRUCTURE
- Root: JSONArray of heroes
- Hero fields: id, name, category, skins
- Image field: hero.skins[].image

BASE IMAGE PRIORITY
1. skin_name == "Backup"
2. skin id ends with "_001"
3. first enabled skin with an image

INSTALL
1. Replace HeroGuideLoader.java.
2. Replace SkinHeroBannerResolver.java.
3. Keep/add TopCropImageView.java.
4. In heroguide.xml, imageview_hero_background must use:
   com.iandev.masterkit.TopCropImageView

IMPORTANT
- Main hero header only is changed.
- Counter and Strong Against remain unchanged.
- Current API backdrop appears first, then the skins.json base image replaces it.
