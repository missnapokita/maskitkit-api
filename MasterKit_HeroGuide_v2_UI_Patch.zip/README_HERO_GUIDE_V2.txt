MASTERKIT HERO GUIDE V2

Ready-to-copy project patch.

Main changes:
- Main hero uses backdrop/landscape first, then portrait fallback.
- Counter Heroes and Strong Against prefer icon/portrait/head_icon/avatar fields.
- Assassin and Jungle chips restored.
- Dual roles such as Fighter/Assassin are supported.
- Duplicate Jungle/Jungler becomes Jungle.
- Specialty/Hero chip and yellow tier button are hidden.
- Compact animated circular Win/Pick/Ban progress.
- Existing emblem, spell, builds, combos, counters, and strong-against logic retained.
- No additional onCreate code is required.

HeroguideActivity remains:
HeroGuideLoader.apply(this);

The generated mockup itself is not included as an app asset.
Only original XML/custom-view UI assets are included.
MLBB hero/item/emblem artwork continues loading from your API.
