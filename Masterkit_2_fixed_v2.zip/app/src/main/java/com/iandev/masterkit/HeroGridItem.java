package com.iandev.masterkit;

public class HeroGridItem {

	public String id = "";
	public String name = "";
	public String category = "";
	public String image = "";
	public boolean enabled = true;
}