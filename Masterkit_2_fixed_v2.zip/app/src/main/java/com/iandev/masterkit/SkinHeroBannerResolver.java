package com.iandev.masterkit;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Locale;

/**
 * Exact parser for:
 * https://raw.githubusercontent.com/missnapokita/masterkiter/refs/heads/main/skins.json
 *
 * Actual structure:
 * [
 *   {
 *     "id": "alpha",
 *     "name": "Alpha",
 *     "category": "fighter",
 *     "skins": [
 *       {
 *         "id": "alpha_001",
 *         "skin_name": "Backup",
 *         "image": "https://..."
 *       }
 *     ]
 *   }
 * ]
 *
 * Base hero image priority:
 * 1. skin_name == "Backup"
 * 2. skin id ends with "_001"
 * 3. first enabled skin with a valid image
 */
public final class SkinHeroBannerResolver {

	private static final String SKINS_URL =
			"https://raw.githubusercontent.com/missnapokita/masterkiter/refs/heads/main/skins.json";

	private static final HashMap<String, String> BY_ID =
			new HashMap<>();

	private static final HashMap<String, String> BY_NAME =
			new HashMap<>();

	private static boolean loaded;
	private static boolean failed;

	private SkinHeroBannerResolver() {
	}

	public static String getBaseSkinImageBlocking(
			String heroId,
			String heroName) {

		ensureLoaded();

		String idKey =
				normalize(heroId);

		String nameKey =
				normalize(heroName);

		String image =
				BY_ID.get(idKey);

		if (image != null && !image.isEmpty()) {
			return image;
		}

		image = BY_NAME.get(nameKey);

		return image == null ? "" : image;
	}

	private static synchronized void ensureLoaded() {

		if (loaded || failed) {
			return;
		}

		HttpURLConnection connection = null;

		try {
			connection =
					(HttpURLConnection)
							new URL(SKINS_URL)
									.openConnection();

			connection.setRequestMethod("GET");
			connection.setConnectTimeout(10000);
			connection.setReadTimeout(25000);
			connection.setUseCaches(true);

			connection.setRequestProperty(
					"Accept",
					"application/json"
			);

			connection.setRequestProperty(
					"User-Agent",
					"MasterKit-Android"
			);

			int responseCode =
					connection.getResponseCode();

			if (responseCode < 200 ||
				responseCode >= 300) {

				failed = true;
				return;
			}

			String response =
					readStream(
							connection.getInputStream()
					);

			Object root =
					new JSONTokener(response)
							.nextValue();

			if (!(root instanceof JSONArray)) {
				failed = true;
				return;
			}

			indexHeroes((JSONArray) root);
			loaded = true;

		} catch (Exception ignored) {
			failed = true;

		} finally {

			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private static void indexHeroes(
			JSONArray heroes) {

		for (int i = 0; i < heroes.length(); i++) {

			JSONObject hero =
					heroes.optJSONObject(i);

			if (hero == null) {
				continue;
			}

			String heroId =
					hero.optString(
							"id",
							""
					).trim();

			String heroName =
					hero.optString(
							"name",
							""
					).trim();

			JSONArray skins =
					hero.optJSONArray("skins");

			if (skins == null ||
				skins.length() == 0) {
				continue;
			}

			String image =
					findBackupImage(skins);

			if (image.isEmpty()) {
				image = find001Image(skins);
			}

			if (image.isEmpty()) {
				image = findFirstValidImage(skins);
			}

			if (image.isEmpty()) {
				continue;
			}

			String idKey =
					normalize(heroId);

			String nameKey =
					normalize(heroName);

			if (!idKey.isEmpty()) {
				BY_ID.put(idKey, image);
			}

			if (!nameKey.isEmpty()) {
				BY_NAME.put(nameKey, image);
			}
		}
	}

	private static String findBackupImage(
			JSONArray skins) {

		for (int i = 0; i < skins.length(); i++) {

			JSONObject skin =
					skins.optJSONObject(i);

			if (skin == null) {
				continue;
			}

			String skinName =
					skin.optString(
							"skin_name",
							""
					).trim();

			String image =
					skin.optString(
							"image",
							""
					).trim();

			if ("backup".equalsIgnoreCase(skinName)
					&& isHttp(image)) {

				return image;
			}
		}

		return "";
	}

	private static String find001Image(
			JSONArray skins) {

		for (int i = 0; i < skins.length(); i++) {

			JSONObject skin =
					skins.optJSONObject(i);

			if (skin == null) {
				continue;
			}

			String skinId =
					skin.optString(
							"id",
							""
					).trim()
					.toLowerCase(Locale.US);

			String image =
					skin.optString(
							"image",
							""
					).trim();

			if (skinId.endsWith("_001")
					&& isHttp(image)) {

				return image;
			}
		}

		return "";
	}

	private static String findFirstValidImage(
			JSONArray skins) {

		for (int i = 0; i < skins.length(); i++) {

			JSONObject skin =
					skins.optJSONObject(i);

			if (skin == null) {
				continue;
			}

			if (skin.has("enabled")
					&& !skin.optBoolean("enabled", true)) {
				continue;
			}

			String image =
					skin.optString(
							"image",
							""
					).trim();

			if (isHttp(image)) {
				return image;
			}
		}

		return "";
	}

	private static boolean isHttp(
			String value) {

		String clean =
				value == null
						? ""
						: value.trim()
								.toLowerCase(Locale.US);

		return clean.startsWith("https://")
				|| clean.startsWith("http://");
	}

	private static String normalize(
			String value) {

		return value == null
				? ""
				: value.toLowerCase(Locale.US)
						.replace("&", "and")
						.replace("’", "")
						.replace("'", "")
						.replace(".", "")
						.replace("-", "")
						.replace("_", "")
						.replace(" ", "")
						.trim();
	}

	private static String readStream(
			InputStream inputStream)
			throws Exception {

		BufferedReader reader =
				new BufferedReader(
						new InputStreamReader(
								inputStream,
								"UTF-8"
						)
				);

		StringBuilder result =
				new StringBuilder();

		String line;

		while ((line = reader.readLine()) != null) {
			result.append(line);
		}

		reader.close();

		return result.toString();
	}
}
