package com.iandev.masterkit;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Home1Fragment extends Fragment {

	private static final String SUGGESTED_URL =
			"https://raw.githubusercontent.com/missnapokita/hero.json/refs/heads/main/suggested.json";

	private static final String HERO_META_URL =
			"https://mapi.mobilelegends.com/hero/list";

	private View rootView;

	public Home1Fragment() {
		// Required empty constructor
	}

	@Nullable
	@Override
	public View onCreateView(
			@NonNull LayoutInflater inflater,
			@Nullable ViewGroup container,
			@Nullable Bundle savedInstanceState) {

		rootView = inflater.inflate(
				R.layout.home1_fragment,
				container,
				false
		);

		/*
		 * Load banner data.
		 */
		loadBannerData();

		/*
		 * Load heroes sa recyclerview1.
		 */
		Activity activity = getActivity();

		if (activity != null && rootView != null) {

			HeroGridLoader.load(
					activity,
					rootView
			);
		}

		return rootView;
	}

	private void loadBannerData() {

		loadJson(
				SUGGESTED_URL,
				new JsonCallback() {

					@Override
					public void onSuccess(
							String response) {

						Activity activity =
								getActivity();

						if (activity == null
								|| rootView == null
								|| !isAdded()) {

							return;
						}

						BannerSlider.setSuggestedData(
								activity,
								rootView,
								response
						);
					}

					@Override
					public void onError(
							String message) {

						showToast(
								"Suggested error: "
										+ message
						);
					}
				}
		);

		loadJson(
				HERO_META_URL,
				new JsonCallback() {

					@Override
					public void onSuccess(
							String response) {

						Activity activity =
								getActivity();

						if (activity == null
								|| rootView == null
								|| !isAdded()) {

							return;
						}

						BannerSlider.setHeroMetaData(
								activity,
								rootView,
								response
						);
					}

					@Override
					public void onError(
							String message) {

						/*
						 * Hindi ibi-blank ang banner
						 * kapag hero icon API lang
						 * ang pumalya.
						 */
						showToast(
								"Icon error: "
										+ message
						);
					}
				}
		);
	}

	private void loadJson(
			final String link,
			final JsonCallback callback) {

		new AsyncTask<Void, Void, String>() {

			private String errorMessage = "";

			@Override
			protected String doInBackground(
					Void... params) {

				HttpURLConnection connection = null;
				InputStream inputStream = null;
				BufferedReader reader = null;

				try {

					URL url =
							new URL(link);

					connection =
							(HttpURLConnection)
									url.openConnection();

					connection.setRequestMethod(
							"GET"
					);

					connection.setConnectTimeout(
							12000
					);

					connection.setReadTimeout(
							15000
					);

					connection.setUseCaches(false);

					connection.setRequestProperty(
							"User-Agent",
							"Mozilla/5.0"
					);

					int responseCode =
							connection.getResponseCode();

					if (responseCode < 200
							|| responseCode >= 300) {

						errorMessage =
								"HTTP "
										+ responseCode;

						return null;
					}

					inputStream =
							connection.getInputStream();

					reader =
							new BufferedReader(
									new InputStreamReader(
											inputStream,
											"UTF-8"
									)
							);

					StringBuilder result =
							new StringBuilder();

					String line;

					while ((line =
							reader.readLine()) != null) {

						result.append(line);
					}

					return result.toString();

				} catch (Exception error) {

					errorMessage =
							error.getMessage() == null
									? error.toString()
									: error.getMessage();

					return null;

				} finally {

					try {

						if (reader != null) {
							reader.close();
						}

					} catch (Exception ignored) {
					}

					try {

						if (inputStream != null) {
							inputStream.close();
						}

					} catch (Exception ignored) {
					}

					if (connection != null) {
						connection.disconnect();
					}
				}
			}

			@Override
			protected void onPostExecute(
					String response) {

				if (!isAdded()
						|| rootView == null) {

					return;
				}

				if (response != null
						&& response.trim()
								.length() > 0) {

					callback.onSuccess(response);

				} else {

					callback.onError(
							errorMessage.length() == 0
									? "Empty response"
									: errorMessage
					);
				}
			}

		}.execute();
	}

	private void showToast(
			String message) {

		Activity activity =
				getActivity();

		if (activity == null
				|| !isAdded()) {

			return;
		}

		android.widget.Toast.makeText(
				activity,
				message,
				android.widget.Toast.LENGTH_LONG
		).show();
	}

	@Override
	public void onDestroyView() {

		BannerSlider.release();

		rootView = null;

		super.onDestroyView();
	}

	private interface JsonCallback {

		void onSuccess(
				String response
		);

		void onError(
				String message
		);
	}
}