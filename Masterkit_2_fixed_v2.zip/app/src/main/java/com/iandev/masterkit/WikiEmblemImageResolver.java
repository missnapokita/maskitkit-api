package com.iandev.masterkit;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;

/**
 * Resolves emblem and talent icons from:
 * https://mlbb-wiki-api.vercel.app/api/emblem
 *
 * The endpoint may contain both emblem names and talent names.
 * This resolver recursively scans the response and stores every
 * name/title/label -> icon/image URL pair it can find.
 */
public final class WikiEmblemImageResolver {

	private static final String API_URL =
			"https://mlbb-wiki-api.vercel.app/api/emblem";

	private static final HashMap<String, String> IMAGES =
			new HashMap<>();

	private static boolean loaded;

	private WikiEmblemImageResolver() {
	}

	public static String getImageBlocking(String name) {

		String key = normalize(name);

		if (key.isEmpty()) {
			return "";
		}

		synchronized (WikiEmblemImageResolver.class) {

			if (!loaded) {
				loadAll();
			}

			String direct = IMAGES.get(key);

			if (direct != null && !direct.isEmpty()) {
				return direct;
			}

			/*
			 * Flexible matching:
			 * "Custom Mage Emblem" can match "Mage",
			 * while "Agility Talent" can match "Agility".
			 */
			for (String storedKey : IMAGES.keySet()) {

				if (storedKey.equals(key)
						|| storedKey.contains(key)
						|| key.contains(storedKey)) {

					String image = IMAGES.get(storedKey);

					if (image != null && !image.isEmpty()) {
						return image;
					}
				}
			}
		}

		return "";
	}

	private static void loadAll() {

		loaded = true;

		HttpURLConnection connection = null;

		try {
			connection =
					(HttpURLConnection)
							new URL(API_URL).openConnection();

			connection.setRequestMethod("GET");
			connection.setConnectTimeout(15000);
			connection.setReadTimeout(30000);
			connection.setUseCaches(true);

			connection.setRequestProperty(
					"Accept",
					"application/json"
			);

			connection.setRequestProperty(
					"User-Agent",
					"Mozilla/5.0 (Android; MasterKit)"
			);

			int code = connection.getResponseCode();

			if (code < 200 || code >= 300) {
				return;
			}

			String response =
					readStream(connection.getInputStream());

			JSONObject root =
					new JSONObject(response);

			Object data =
					root.has("data")
							? root.opt("data")
							: root;

			scan(data);

		} catch (Exception ignored) {

		} finally {

			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private static void scan(Object node) {

		if (node == null || node == JSONObject.NULL) {
			return;
		}

		if (node instanceof JSONArray) {

			JSONArray array =
					(JSONArray) node;

			for (int i = 0; i < array.length(); i++) {
				scan(array.opt(i));
			}

			return;
		}

		if (!(node instanceof JSONObject)) {
			return;
		}

		JSONObject object =
				(JSONObject) node;

		String image =
				firstHttp(
						object,
						"icon",
						"image",
						"emblem_icon",
						"talent_icon",
						"icon_url",
						"image_url",
						"src",
						"url"
				);

		if (!image.isEmpty()) {

			addName(
					object.optString("name"),
					image
			);

			addName(
					object.optString("title"),
					image
			);

			addName(
					object.optString("label"),
					image
			);

			addName(
					object.optString("emblem_name"),
					image
			);

			addName(
					object.optString("talent_name"),
					image
			);

			addName(
					object.optString("emblem"),
					image
			);

			addName(
					object.optString("talent"),
					image
			);
		}

		Iterator<String> keys =
				object.keys();

		while (keys.hasNext()) {

			String key =
					keys.next();

			Object value =
					object.opt(key);

			if (value instanceof JSONObject
					|| value instanceof JSONArray) {

				scan(value);
			}
		}
	}

	private static void addName(
			String name,
			String image) {

		String key =
				normalize(name);

		if (!key.isEmpty() && isHttp(image)) {
			IMAGES.put(key, image.trim());
		}
	}

	private static String firstHttp(
			JSONObject object,
			String... keys) {

		for (String key : keys) {

			String value =
					object.optString(key, "").trim();

			if (isHttp(value)) {
				return value;
			}
		}

		return "";
	}

	private static String readStream(
			InputStream inputStream)
			throws Exception {

		BufferedReader reader =
				new BufferedReader(
						new InputStreamReader(
								inputStream,
								"UTF-8"
						)
				);

		StringBuilder result =
				new StringBuilder();

		String line;

		while ((line = reader.readLine()) != null) {
			result.append(line);
		}

		reader.close();

		return result.toString();
	}

	private static boolean isHttp(
			String value) {

		String clean =
				value == null
						? ""
						: value.trim().toLowerCase(Locale.US);

		return clean.startsWith("https://")
				|| clean.startsWith("http://");
	}

	private static String normalize(
			String value) {

		return value == null
				? ""
				: value.toLowerCase(Locale.US)
						.replace("&", "and")
						.replace("custom", "")
						.replace("emblem", "")
						.replace("talent", "")
						.replace("’", "")
						.replace("'", "")
						.replace("-", "")
						.replace("_", "")
						.replace(" ", "")
						.trim();
	}
}
