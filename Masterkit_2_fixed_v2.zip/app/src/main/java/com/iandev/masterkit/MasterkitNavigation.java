package com.iandev.masterkit;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

public class MasterkitNavigation {

	private static final int ACTIVE_COLOR =
			Color.parseColor("#FFA31A");

	private static final int INACTIVE_COLOR =
			Color.parseColor("#8A8A8A");

	private MasterkitNavigation() {
		// Utility class lamang.
	}

	public static void setup(final Activity activity) {

		if (activity == null || activity.isFinishing()) {
			return;
		}

		final ViewPager viewPager =
				(ViewPager) activity.findViewById(
						R.id.viewpager_main
				);

		final LinearLayout navbarHome =
				(LinearLayout) activity.findViewById(
						R.id.navbar_home
				);

		final LinearLayout navbarMenu =
				(LinearLayout) activity.findViewById(
						R.id.navbar_menu
				);

		final LinearLayout navbarSettings =
				(LinearLayout) activity.findViewById(
						R.id.navbar_settings
				);

		final ImageView imageHome =
				(ImageView) activity.findViewById(
						R.id.imageview_home
				);

		final ImageView imageMenu =
				(ImageView) activity.findViewById(
						R.id.imageview_menu
				);

		final ImageView imageSettings =
				(ImageView) activity.findViewById(
						R.id.imageview_settings
				);

		final TextView textHome =
				(TextView) activity.findViewById(
						R.id.textview_nav_home
				);

		final TextView textMenu =
				(TextView) activity.findViewById(
						R.id.textview_nav_menu
				);

		final TextView textSettings =
				(TextView) activity.findViewById(
						R.id.textview_nav_settings
				);

		if (viewPager == null
				|| navbarHome == null
				|| navbarMenu == null
				|| navbarSettings == null
				|| imageHome == null
				|| imageMenu == null
				|| imageSettings == null
				|| textHome == null
				|| textMenu == null
				|| textSettings == null) {

			return;
		}

		// Product font
		Typeface productFont = loadProductFont(activity);

		textHome.setTypeface(productFont);
		textMenu.setTypeface(productFont);
		textSettings.setTypeface(productFont);

		// Ripple/clickable
		navbarHome.setClickable(true);
		navbarMenu.setClickable(true);
		navbarSettings.setClickable(true);

		navbarHome.setFocusable(true);
		navbarMenu.setFocusable(true);
		navbarSettings.setFocusable(true);

		// Default page
		applySelectedPage(
				0,
				navbarHome,
				navbarMenu,
				navbarSettings,
				imageHome,
				imageMenu,
				imageSettings,
				textHome,
				textMenu,
				textSettings
		);

		navbarHome.setOnClickListener(
				new View.OnClickListener() {

					@Override
					public void onClick(View view) {

						animateClick(navbarHome);

						if (viewPager.getCurrentItem() != 0) {
							viewPager.setCurrentItem(0, true);
						}
					}
				}
		);

		navbarMenu.setOnClickListener(
				new View.OnClickListener() {

					@Override
					public void onClick(View view) {

						animateClick(navbarMenu);

						if (viewPager.getCurrentItem() != 1) {
							viewPager.setCurrentItem(1, true);
						}
					}
				}
		);

		navbarSettings.setOnClickListener(
				new View.OnClickListener() {

					@Override
					public void onClick(View view) {

						animateClick(navbarSettings);

						if (viewPager.getCurrentItem() != 2) {
							viewPager.setCurrentItem(2, true);
						}
					}
				}
		);

		viewPager.addOnPageChangeListener(
				new ViewPager.SimpleOnPageChangeListener() {

					@Override
					public void onPageSelected(int position) {

						super.onPageSelected(position);

						applySelectedPage(
								position,
								navbarHome,
								navbarMenu,
								navbarSettings,
								imageHome,
								imageMenu,
								imageSettings,
								textHome,
								textMenu,
								textSettings
						);
					}
				}
		);
	}

	private static void applySelectedPage(
			int selectedPage,
			LinearLayout navbarHome,
			LinearLayout navbarMenu,
			LinearLayout navbarSettings,
			ImageView imageHome,
			ImageView imageMenu,
			ImageView imageSettings,
			TextView textHome,
			TextView textMenu,
			TextView textSettings) {

		applyItemState(
				navbarHome,
				imageHome,
				textHome,
				selectedPage == 0
		);

		applyItemState(
				navbarMenu,
				imageMenu,
				textMenu,
				selectedPage == 1
		);

		applyItemState(
				navbarSettings,
				imageSettings,
				textSettings,
				selectedPage == 2
		);
	}

	private static void applyItemState(
			LinearLayout container,
			ImageView icon,
			TextView text,
			boolean selected) {

		int color =
				selected
						? ACTIVE_COLOR
						: INACTIVE_COLOR;

		icon.setColorFilter(color);
		text.setTextColor(color);

		text.setTypeface(
				text.getTypeface(),
				selected
						? Typeface.BOLD
						: Typeface.NORMAL
		);

		container.setAlpha(
				selected ? 1f : 0.82f
		);

		icon.animate()
				.scaleX(selected ? 1.12f : 1f)
				.scaleY(selected ? 1.12f : 1f)
				.setDuration(180L)
				.start();

		text.animate()
				.alpha(selected ? 1f : 0.82f)
				.setDuration(180L)
				.start();
	}

	private static void animateClick(final View view) {

		if (view == null) {
			return;
		}

		view.animate()
				.scaleX(0.92f)
				.scaleY(0.92f)
				.setDuration(80L)
				.withEndAction(
						new Runnable() {

							@Override
							public void run() {

								view.animate()
										.scaleX(1f)
										.scaleY(1f)
										.setDuration(120L)
										.start();
							}
						}
				)
				.start();
	}

	private static Typeface loadProductFont(
			Activity activity) {

		try {

			return Typeface.createFromAsset(
					activity.getAssets(),
					"fonts/product.ttf"
			);

		} catch (Exception firstError) {

			try {

				return Typeface.createFromAsset(
						activity.getAssets(),
						"product.ttf"
				);

			} catch (Exception secondError) {

				return Typeface.DEFAULT;
			}
		}
	}
}