package com.iandev.masterkit;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BannerAdapter
		extends RecyclerView.Adapter<BannerAdapter.Holder> {

	private final Activity activity;
	private final ArrayList<BannerItem> list;

	public BannerAdapter(
			Activity activity,
			ArrayList<BannerItem> list) {

		this.activity = activity;
		this.list = list;
	}

	@NonNull
	@Override
	public Holder onCreateViewHolder(
			@NonNull ViewGroup parent,
			int viewType) {

		View view = LayoutInflater
				.from(activity)
				.inflate(
						R.layout.banner_item,
						parent,
						false
				);

		return new Holder(view);
	}

	@Override
	public void onBindViewHolder(
			@NonNull Holder holder,
			int position) {

		final BannerItem item = list.get(position);

		holder.title.setText(item.hero_name);
		holder.skin.setText(item.skin_name);

		SimpleImageLoader.load(
				item.image,
				holder.banner,
				R.drawable.des
		);

		SimpleImageLoader.load(
				item.icon,
				holder.icon,
				R.drawable.des
		);
	}

	@Override
	public int getItemCount() {
		return list == null ? 0 : list.size();
	}

	public static class Holder
			extends RecyclerView.ViewHolder {

		ImageView banner;
		ImageView icon;
		TextView title;
		TextView skin;

		public Holder(View itemView) {
			super(itemView);

			banner = itemView.findViewById(
					R.id.imageview_banner
			);

			icon = itemView.findViewById(
					R.id.imageview_hero_icon
			);

			title = itemView.findViewById(
					R.id.textview_title
			);

			skin = itemView.findViewById(
					R.id.textview_skin
			);
		}
	}
}