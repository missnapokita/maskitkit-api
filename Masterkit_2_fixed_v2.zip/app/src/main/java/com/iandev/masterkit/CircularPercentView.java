package com.iandev.masterkit;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import java.util.Locale;

public class CircularPercentView extends View {
	private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint progress = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private float percent = 0f;
	private String label = "RATE";
	public CircularPercentView(Context c) { super(c); init(); }
	public CircularPercentView(Context c, AttributeSet a) { super(c,a); init(); }
	public CircularPercentView(Context c, AttributeSet a, int s) { super(c,a,s); init(); }
	private void init() {
		float d=getResources().getDisplayMetrics().density;
		track.setStyle(Paint.Style.STROKE); track.setStrokeWidth(7*d); track.setColor(Color.parseColor("#2A2A2A")); track.setStrokeCap(Paint.Cap.ROUND);
		progress.setStyle(Paint.Style.STROKE); progress.setStrokeWidth(7*d); progress.setColor(Color.parseColor("#FFB300")); progress.setStrokeCap(Paint.Cap.ROUND);
		valuePaint.setColor(Color.WHITE); valuePaint.setTextAlign(Paint.Align.CENTER); valuePaint.setFakeBoldText(true); valuePaint.setTextSize(16*d);
		labelPaint.setColor(Color.parseColor("#777777")); labelPaint.setTextAlign(Paint.Align.CENTER); labelPaint.setFakeBoldText(true); labelPaint.setTextSize(8*d);
	}
	public void setData(double value, String text) {
		percent = Double.isNaN(value) ? 0f : (float)Math.max(0, Math.min(100, value));
		label = text == null ? "RATE" : text; invalidate();
	}
	@Override protected void onDraw(Canvas c) {
		super.onDraw(c); float d=getResources().getDisplayMetrics().density; float cx=getWidth()/2f, cy=getHeight()/2f-5*d; float r=Math.min(getWidth(),getHeight()-18*d)/2f-9*d; RectF oval=new RectF(cx-r,cy-r,cx+r,cy+r);
		c.drawArc(oval,-90,360,false,track); c.drawArc(oval,-90,360f*percent/100f,false,progress);
		String v = percent == Math.floor(percent) ? String.format(Locale.US,"%.0f%%",percent) : String.format(Locale.US,"%.2f%%",percent).replaceAll("0+%$","%").replace(".%","%");
		Paint.FontMetrics fm=valuePaint.getFontMetrics(); c.drawText(v,cx,cy-(fm.ascent+fm.descent)/2f,valuePaint); c.drawText(label,cx,getHeight()-3*d,labelPaint);
	}
}
