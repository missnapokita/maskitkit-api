package com.iandev.masterkit;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.*;
import com.iandev.masterkit.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private MainBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		// KUNIN ANG IMAGEVIEW
		final android.widget.ImageView logo =
		(android.widget.ImageView) findViewById(R.id.imageview_logo);
		
		// SAFETY CHECK
		if (logo == null) {
			android.widget.Toast.makeText(
			getApplicationContext(),
			"Hindi makita ang logo. Check ang XML ID.",
			android.widget.Toast.LENGTH_LONG
			).show();
			return;
		}
		
		// LOGO STARTING STATE
		logo.setScaleX(0.85f);
		logo.setScaleY(0.85f);
		logo.setAlpha(0f);
		
		// LOGO ANIMATION
		logo.animate()
		.scaleX(1f)
		.scaleY(1f)
		.alpha(1f)
		.setDuration(700)
		.start();
		
		// AFTER 1.8 SECONDS OPEN HOME ACTIVITY
		new android.os.Handler(android.os.Looper.getMainLooper())
		.postDelayed(new Runnable() {
			@Override
			public void run() {
				
				startActivity(new android.content.Intent(
				MainActivity.this,
				HomeActivity.class));
				
				overridePendingTransition(
				android.R.anim.fade_in,
				android.R.anim.fade_out);
				
				finish();
				
			}
		}, 1800);
		binding.progressbarLoading.setVisibility(View.INVISIBLE);
		_NavStatusBarColor("#080808", "#080808");
	}
	
	public void _NavStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
}