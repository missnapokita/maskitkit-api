package com.iandev.masterkit;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.LruCache;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Comparator;

public class SimpleImageLoader {

    // Sapat para sa MasterKit banners.
    private static final long MAX_DISK_CACHE_SIZE =
            100L * 1024L * 1024L;

    // Optimized para sa 16:9 banner images.
    private static final int MAX_IMAGE_WIDTH = 1280;
    private static final int MAX_IMAGE_HEIGHT = 720;

    private static final LruCache<String, Bitmap> memoryCache;

    static {

        int maxMemory =
                (int) (Runtime.getRuntime().maxMemory() / 1024);

        int cacheSize = maxMemory / 6;

        memoryCache = new LruCache<String, Bitmap>(cacheSize) {

            @Override
            protected int sizeOf(String key, Bitmap bitmap) {

                if (bitmap == null) {
                    return 0;
                }

                return bitmap.getByteCount() / 1024;
            }
        };
    }

    /*
     * Simpleng version para walang loading/shimmer view.
     *
     * Example:
     * SimpleImageLoader.load(
     *     item.image,
     *     holder.banner,
     *     R.drawable.des
     * );
     */
    public static void load(
            final String link,
            final ImageView image,
            final int placeholder) {

        load(link, image, placeholder, null);
    }

    /*
     * Version na may optional loading View.
     * Puwedeng null ang loadingView.
     */
    public static void load(
            final String link,
            final ImageView image,
            final int placeholder,
            final View loadingView) {

        if (image == null) {
            return;
        }

        final String requestKey =
                link == null ? "" : link.trim();

        image.setTag(requestKey);

        if (requestKey.length() == 0
                || requestKey.equalsIgnoreCase("null")
                || requestKey.equalsIgnoreCase("n/a")) {

            hideLoading(loadingView);

            image.clearAnimation();
            image.setImageResource(placeholder);
            image.setVisibility(View.VISIBLE);

            return;
        }

        Bitmap cachedBitmap = memoryCache.get(requestKey);

        if (cachedBitmap != null
                && !cachedBitmap.isRecycled()) {

            hideLoading(loadingView);

            image.clearAnimation();
            image.setImageBitmap(cachedBitmap);
            image.setVisibility(View.VISIBLE);

            return;
        }

        image.clearAnimation();
        image.setImageResource(placeholder);
        image.setVisibility(View.INVISIBLE);

        showLoading(loadingView);

        new AsyncTask<Void, Void, Bitmap>() {

            @Override
            protected Bitmap doInBackground(Void... params) {

                File tempFile = null;

                try {

                    File cacheDir = new File(
                            image.getContext().getFilesDir(),
                            "masterkit_images"
                    );

                    if (!cacheDir.exists()) {
                        cacheDir.mkdirs();
                    }

                    cleanDiskCache(cacheDir);

                    String lowerUrl =
                            requestKey.toLowerCase();

                    boolean isPng =
                            lowerUrl.contains("logo")
                                    || lowerUrl.contains("/logos/")
                                    || lowerUrl.endsWith(".png")
                                    || lowerUrl.contains(".png?");

                    String extension =
                            isPng ? ".png" : ".jpg";

                    String fileName =
                            md5(requestKey);

                    File imageFile = new File(
                            cacheDir,
                            fileName + extension
                    );

                    int reqWidth =
                            image.getWidth() > 0
                                    ? image.getWidth()
                                    : 1280;

                    int reqHeight =
                            image.getHeight() > 0
                                    ? image.getHeight()
                                    : 720;

                    reqWidth = Math.min(
                            reqWidth,
                            MAX_IMAGE_WIDTH
                    );

                    reqHeight = Math.min(
                            reqHeight,
                            MAX_IMAGE_HEIGHT
                    );

                    Bitmap bitmap;

                    // Subukan muna ang disk cache.
                    if (imageFile.exists()
                            && imageFile.length() > 0) {

                        imageFile.setLastModified(
                                System.currentTimeMillis()
                        );

                        bitmap = decodeFile(
                                imageFile,
                                reqWidth,
                                reqHeight
                        );

                        if (bitmap != null) {

                            putInMemoryCache(
                                    requestKey,
                                    bitmap
                            );

                            return bitmap;

                        } else {

                            imageFile.delete();
                        }
                    }

                    URLConnection connection =
                            new URL(requestKey)
                                    .openConnection();

                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(15000);
                    connection.setUseCaches(true);

                    connection.setRequestProperty(
                            "User-Agent",
                            "Mozilla/5.0 (Android)"
                    );

                    InputStream input =
                            new BufferedInputStream(
                                    connection.getInputStream()
                            );

                    tempFile = new File(
                            cacheDir,
                            fileName + ".tmp"
                    );

                    FileOutputStream output =
                            new FileOutputStream(tempFile);

                    byte[] buffer = new byte[8192];

                    int read;

                    while ((read = input.read(buffer)) != -1) {

                        if (isCancelled()) {

                            try {
                                output.close();
                            } catch (Exception ignored) {
                            }

                            try {
                                input.close();
                            } catch (Exception ignored) {
                            }

                            if (tempFile.exists()) {
                                tempFile.delete();
                            }

                            return null;
                        }

                        output.write(buffer, 0, read);
                    }

                    output.flush();
                    output.close();
                    input.close();

                    bitmap = decodeFile(
                            tempFile,
                            reqWidth,
                            reqHeight
                    );

                    if (bitmap == null) {

                        if (tempFile.exists()) {
                            tempFile.delete();
                        }

                        if (imageFile.exists()) {
                            imageFile.delete();
                        }

                        return null;
                    }

                    FileOutputStream compressOutput =
                            new FileOutputStream(imageFile);

                    if (isPng) {

                        bitmap.compress(
                                Bitmap.CompressFormat.PNG,
                                100,
                                compressOutput
                        );

                    } else {

                        bitmap.compress(
                                Bitmap.CompressFormat.JPEG,
                                82,
                                compressOutput
                        );
                    }

                    compressOutput.flush();
                    compressOutput.close();

                    if (tempFile.exists()) {
                        tempFile.delete();
                    }

                    Bitmap finalBitmap = decodeFile(
                            imageFile,
                            reqWidth,
                            reqHeight
                    );

                    if (finalBitmap != null) {

                        putInMemoryCache(
                                requestKey,
                                finalBitmap
                        );

                        if (finalBitmap != bitmap
                                && bitmap != null
                                && !bitmap.isRecycled()) {

                            bitmap.recycle();
                        }

                        return finalBitmap;
                    }

                    putInMemoryCache(
                            requestKey,
                            bitmap
                    );

                    return bitmap;

                } catch (Exception ignored) {

                    if (tempFile != null
                            && tempFile.exists()) {

                        tempFile.delete();
                    }

                    return null;
                }
            }

            @Override
            protected void onPostExecute(Bitmap bitmap) {

                if (image == null) {
                    return;
                }

                String currentTag =
                        String.valueOf(image.getTag());

                // Mahalaga ito para hindi maling image ang
                // lumabas sa recycled ViewPager/RecyclerView item.
                if (!requestKey.equals(currentTag)) {
                    return;
                }

                hideLoading(loadingView);

                if (bitmap != null
                        && !bitmap.isRecycled()) {

                    image.setImageBitmap(bitmap);
                    image.setVisibility(View.VISIBLE);

                    fadeIn(image);

                } else {

                    image.clearAnimation();
                    image.setImageResource(placeholder);
                    image.setVisibility(View.VISIBLE);
                }
            }

        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    private static void putInMemoryCache(
            String key,
            Bitmap bitmap) {

        if (key == null
                || bitmap == null
                || bitmap.isRecycled()) {

            return;
        }

        if (memoryCache.get(key) == null) {

            memoryCache.put(key, bitmap);
        }
    }

    private static void fadeIn(ImageView image) {

        if (image == null) {
            return;
        }

        try {

            AlphaAnimation animation =
                    new AlphaAnimation(0.35f, 1.0f);

            animation.setDuration(180);
            animation.setFillAfter(true);

            image.startAnimation(animation);

        } catch (Exception ignored) {
        }
    }

    private static void showLoading(View loadingView) {

        if (loadingView == null) {
            return;
        }

        try {

            loadingView.setVisibility(View.VISIBLE);

        } catch (Exception ignored) {
        }
    }

    private static void hideLoading(View loadingView) {

        if (loadingView == null) {
            return;
        }

        try {

            loadingView.setVisibility(View.GONE);

        } catch (Exception ignored) {
        }
    }

    private static void cleanDiskCache(File cacheDir) {

        try {

            File[] files = cacheDir.listFiles();

            if (files == null
                    || files.length == 0) {

                return;
            }

            long totalSize = 0;

            for (File file : files) {

                if (file != null
                        && file.exists()) {

                    totalSize += file.length();
                }
            }

            if (totalSize <= MAX_DISK_CACHE_SIZE) {
                return;
            }

            Arrays.sort(
                    files,
                    new Comparator<File>() {

                        @Override
                        public int compare(File first, File second) {

                            if (first == null
                                    && second == null) {

                                return 0;
                            }

                            if (first == null) {
                                return -1;
                            }

                            if (second == null) {
                                return 1;
                            }

                            return Long.compare(
                                    first.lastModified(),
                                    second.lastModified()
                            );
                        }
                    }
            );

            for (File file : files) {

                if (totalSize
                        <= MAX_DISK_CACHE_SIZE) {

                    break;
                }

                if (file == null
                        || !file.exists()) {

                    continue;
                }

                long fileSize = file.length();

                if (file.delete()) {

                    totalSize -= fileSize;
                }
            }

        } catch (Exception ignored) {
        }
    }

    private static Bitmap decodeFile(
            File file,
            int reqWidth,
            int reqHeight) {

        if (file == null
                || !file.exists()
                || file.length() <= 0) {

            return null;
        }

        try {

            BitmapFactory.Options bounds =
                    new BitmapFactory.Options();

            bounds.inJustDecodeBounds = true;

            BitmapFactory.decodeFile(
                    file.getAbsolutePath(),
                    bounds
            );

            if (bounds.outWidth <= 0
                    || bounds.outHeight <= 0) {

                return null;
            }

            BitmapFactory.Options options =
                    new BitmapFactory.Options();

            options.inSampleSize =
                    calculateInSampleSize(
                            bounds,
                            reqWidth,
                            reqHeight
                    );

            options.inPreferredConfig =
                    Bitmap.Config.RGB_565;

            options.inDither = true;
            options.inScaled = false;

            return BitmapFactory.decodeFile(
                    file.getAbsolutePath(),
                    options
            );

        } catch (OutOfMemoryError error) {

            memoryCache.evictAll();

            return null;

        } catch (Exception ignored) {

            return null;
        }
    }

    private static int calculateInSampleSize(
            BitmapFactory.Options options,
            int reqWidth,
            int reqHeight) {

        int imageHeight = options.outHeight;
        int imageWidth = options.outWidth;

        int sampleSize = 1;

        if (reqWidth <= 0) {
            reqWidth = MAX_IMAGE_WIDTH;
        }

        if (reqHeight <= 0) {
            reqHeight = MAX_IMAGE_HEIGHT;
        }

        if (imageHeight > reqHeight
                || imageWidth > reqWidth) {

            int halfHeight = imageHeight / 2;
            int halfWidth = imageWidth / 2;

            while ((halfHeight / sampleSize)
                    >= reqHeight
                    && (halfWidth / sampleSize)
                    >= reqWidth) {

                sampleSize *= 2;
            }
        }

        return Math.max(1, sampleSize);
    }

    private static String md5(String text) {

        try {

            MessageDigest digest =
                    MessageDigest.getInstance("MD5");

            byte[] bytes =
                    digest.digest(
                            text.getBytes("UTF-8")
                    );

            StringBuilder builder =
                    new StringBuilder();

            for (byte value : bytes) {

                String hex =
                        Integer.toHexString(
                                value & 0xff
                        );

                if (hex.length() == 1) {
                    builder.append('0');
                }

                builder.append(hex);
            }

            return builder.toString();

        } catch (Exception ignored) {

            return String.valueOf(
                    text == null
                            ? 0
                            : text.hashCode()
            );
        }
    }

    public static void clearMemoryCache() {

        try {

            memoryCache.evictAll();

        } catch (Exception ignored) {
        }
    }
}