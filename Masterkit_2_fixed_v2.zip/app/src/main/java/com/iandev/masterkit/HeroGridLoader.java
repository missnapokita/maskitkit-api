package com.iandev.masterkit;

import android.app.Activity;
import android.os.AsyncTask;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

public class HeroGridLoader {

	private static final String JSON_URL =
			"https://raw.githubusercontent.com/missnapokita/masterkiter/refs/heads/main/skins.json";

	private HeroGridLoader() {
	}

	public static void load(
			final Activity activity,
			final View rootView) {

		if (activity == null
				|| rootView == null
				|| activity.isFinishing()) {

			return;
		}

		final RecyclerView recyclerView =
				(RecyclerView) rootView.findViewById(
						R.id.recyclerview1
				);

		final EditText searchEditText =
				(EditText) rootView.findViewById(
						R.id.edittext1
				);

		if (recyclerView == null) {

			Toast.makeText(
					activity,
					"recyclerview1 not found",
					Toast.LENGTH_LONG
			).show();

			return;
		}

		recyclerView.setLayoutManager(
				new GridLayoutManager(
						activity,
						3
				)
		);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(true);
		recyclerView.setItemAnimator(null);

		new AsyncTask<Void, Void, ArrayList<HeroGridItem>>() {

			private String errorMessage = "";

			@Override
			protected ArrayList<HeroGridItem> doInBackground(
					Void... params) {

				HttpURLConnection connection = null;
				BufferedReader reader = null;
				InputStream input = null;

				try {

					URL url =
							new URL(JSON_URL);

					connection =
							(HttpURLConnection)
									url.openConnection();

					connection.setRequestMethod("GET");
					connection.setConnectTimeout(15000);
					connection.setReadTimeout(25000);
					connection.setUseCaches(true);

					connection.setRequestProperty(
							"User-Agent",
							"MasterKit-Android"
					);

					int responseCode =
							connection.getResponseCode();

					if (responseCode < 200
							|| responseCode >= 300) {

						errorMessage =
								"HTTP " + responseCode;

						return null;
					}

					input =
							connection.getInputStream();

					reader =
							new BufferedReader(
									new InputStreamReader(
											input,
											"UTF-8"
									)
							);

					StringBuilder response =
							new StringBuilder();

					String line;

					while ((line = reader.readLine())
							!= null) {

						response.append(line);
					}

					return parseHeroes(
							response.toString()
					);

				} catch (Exception error) {

					errorMessage =
							error.getMessage() == null
									? error.toString()
									: error.getMessage();

					return null;

				} finally {

					try {

						if (reader != null) {
							reader.close();
						}

					} catch (Exception ignored) {
					}

					try {

						if (input != null) {
							input.close();
						}

					} catch (Exception ignored) {
					}

					if (connection != null) {
						connection.disconnect();
					}
				}
			}

			@Override
			protected void onPostExecute(
					ArrayList<HeroGridItem> result) {

				if (activity.isFinishing()) {
					return;
				}

				if (result == null) {

					Toast.makeText(
							activity,
							"Heroes error: "
									+ (
											errorMessage.length() == 0
													? "Unknown error"
													: errorMessage
									),
							Toast.LENGTH_LONG
					).show();

					return;
				}

				if (result.isEmpty()) {

					Toast.makeText(
							activity,
							"No heroes found.",
							Toast.LENGTH_LONG
					).show();

					return;
				}

				/*
				 * Gumagawa tayo ng sariling master copy
				 * para hindi masira ang original list
				 * habang nagse-search.
				 */
				final ArrayList<HeroGridItem> allHeroes =
						new ArrayList<HeroGridItem>();

				allHeroes.addAll(result);

				/*
				 * Initial full hero list.
				 */
				recyclerView.setAdapter(
						new HeroGridAdapter(
								activity,
								new ArrayList<HeroGridItem>(
										allHeroes
								)
						)
				);

				/*
				 * Ikabit ang real-time search.
				 */
				setupSearch(
						activity,
						recyclerView,
						searchEditText,
						allHeroes
				);
			}

		}.execute();
	}

	private static void setupSearch(
			final Activity activity,
			final RecyclerView recyclerView,
			final EditText searchEditText,
			final ArrayList<HeroGridItem> allHeroes) {

		if (activity == null
				|| recyclerView == null
				|| searchEditText == null
				|| allHeroes == null) {

			return;
		}

		/*
		 * Para hindi madoble ang TextWatcher kapag
		 * muling tinawag ang HeroGridLoader.load().
		 */
		Object oldWatcher =
				searchEditText.getTag();

		if (oldWatcher instanceof TextWatcher) {

			searchEditText.removeTextChangedListener(
					(TextWatcher) oldWatcher
			);
		}

		TextWatcher watcher =
				new TextWatcher() {

					@Override
					public void beforeTextChanged(
							CharSequence text,
							int start,
							int count,
							int after) {
					}

					@Override
					public void onTextChanged(
							CharSequence text,
							int start,
							int before,
							int count) {

						String keyword =
								text == null
										? ""
										: text.toString()
												.trim()
												.toLowerCase(
														Locale.US
												);

						ArrayList<HeroGridItem> filtered =
								new ArrayList<HeroGridItem>();

						/*
						 * Kapag blank ang search,
						 * ibalik lahat ng heroes.
						 */
						if (keyword.length() == 0) {

							filtered.addAll(
									allHeroes
							);

						} else {

							for (HeroGridItem hero
									: allHeroes) {

								if (hero == null) {
									continue;
								}

								String heroName =
										hero.name == null
												? ""
												: hero.name
														.toLowerCase(
																Locale.US
														);

								String category =
										hero.category == null
												? ""
												: hero.category
														.toLowerCase(
																Locale.US
														);

								String heroId =
										hero.id == null
												? ""
												: hero.id
														.toLowerCase(
																Locale.US
														);

								/*
								 * Search by:
								 *
								 * Hero name
								 * Hero ID
								 * Category/role
								 */
								if (heroName.contains(keyword)
										|| heroId.contains(keyword)
										|| category.contains(keyword)) {

									filtered.add(hero);
								}
							}
						}

						recyclerView.setAdapter(
								new HeroGridAdapter(
										activity,
										filtered
								)
						);

						/*
						 * Bumalik sa top pagkatapos
						 * mag-filter.
						 */
						if (!filtered.isEmpty()) {

							recyclerView.scrollToPosition(
									0
							);
						}
					}

					@Override
					public void afterTextChanged(
							Editable editable) {
					}
				};

		searchEditText.addTextChangedListener(
				watcher
		);

		searchEditText.setTag(watcher);
	}

	private static ArrayList<HeroGridItem> parseHeroes(
			String response) throws Exception {

		ArrayList<HeroGridItem> heroes =
				new ArrayList<HeroGridItem>();

		if (response == null
				|| response.trim().length() == 0) {

			return heroes;
		}

		Object rootValue =
				new JSONTokener(
						response.trim()
				).nextValue();

		JSONArray heroesArray = null;

		if (rootValue instanceof JSONObject) {

			JSONObject rootObject =
					(JSONObject) rootValue;

			heroesArray =
					rootObject.optJSONArray(
							"heroes"
					);

			if (heroesArray == null) {

				heroesArray =
						rootObject.optJSONArray(
								"data"
						);
			}

			if (heroesArray == null) {

				heroesArray =
						rootObject.optJSONArray(
								"skins"
						);
			}

		} else if (rootValue instanceof JSONArray) {

			heroesArray =
					(JSONArray) rootValue;
		}

		if (heroesArray == null) {
			return heroes;
		}

		for (int i = 0;
			 i < heroesArray.length();
			 i++) {

			JSONObject hero =
					heroesArray.optJSONObject(i);

			if (hero == null) {
				continue;
			}

			String id =
					hero.optString(
							"id",
							""
					).trim();

			String name =
					hero.optString(
							"name",
							""
					).trim();

			String category =
					hero.optString(
							"category",
							""
					).trim();

			boolean enabled =
					hero.optBoolean(
							"enabled",
							true
					);

			if (id.length() == 0
					|| name.length() == 0
					|| !enabled) {

				continue;
			}

			/*
			 * Base heroes lang:
			 *
			 * aamon = kasama
			 * aamon_001 = hindi kasama
			 */
			if (containsNumber(id)) {
				continue;
			}

			HeroGridItem item =
					new HeroGridItem();

			item.id = id;
			item.name = name;
			item.category = category;
			item.enabled = enabled;

			item.image =
					getHeroImageFromSkins(hero);

			if (item.image.length() == 0) {

				item.image =
						firstNonEmpty(
								hero,
								"image",
								"icon",
								"portrait",
								"head",
								"avatar",
								"thumbnail"
						);
			}

			heroes.add(item);
		}

		Collections.sort(
				heroes,
				new Comparator<HeroGridItem>() {

					@Override
					public int compare(
							HeroGridItem first,
							HeroGridItem second) {

						return first.name
								.compareToIgnoreCase(
										second.name
								);
					}
				}
		);

		return heroes;
	}

	private static String getHeroImageFromSkins(
			JSONObject hero) {

		if (hero == null) {
			return "";
		}

		String heroId =
				hero.optString(
						"id",
						""
				).trim();

		JSONArray skins =
				hero.optJSONArray(
						"skins"
				);

		if (skins == null
				|| skins.length() == 0) {

			return "";
		}

		String expectedBaseSkinId =
				heroId.length() == 0
						? ""
						: heroId + "_001";

		String backupImage = "";
		String firstImage = "";

		for (int i = 0;
			 i < skins.length();
			 i++) {

			JSONObject skin =
					skins.optJSONObject(i);

			if (skin == null) {
				continue;
			}

			boolean enabled =
					skin.optBoolean(
							"enabled",
							true
					);

			if (!enabled) {
				continue;
			}

			String skinId =
					skin.optString(
							"id",
							""
					).trim();

			String skinName =
					skin.optString(
							"skin_name",
							""
					).trim();

			String image =
					skin.optString(
							"image",
							""
					).trim();

			if (image.length() == 0
					|| image.equalsIgnoreCase(
							"null"
					)) {

				continue;
			}

			image =
					fixImageUrl(image);

			if (image.length() == 0) {
				continue;
			}

			if (firstImage.length() == 0) {
				firstImage = image;
			}

			/*
			 * Priority:
			 * aamon_001, akai_001, atbp.
			 */
			if (skinId.equalsIgnoreCase(
					expectedBaseSkinId)) {

				return image;
			}

			/*
			 * Fallback:
			 * skin_name = Backup
			 */
			if (backupImage.length() == 0
					&& skinName.equalsIgnoreCase(
							"Backup"
					)) {

				backupImage = image;
			}
		}

		if (backupImage.length() > 0) {
			return backupImage;
		}

		return firstImage;
	}

	private static boolean containsNumber(
			String value) {

		if (value == null) {
			return false;
		}

		for (int i = 0;
			 i < value.length();
			 i++) {

			if (Character.isDigit(
					value.charAt(i))) {

				return true;
			}
		}

		return false;
	}

	private static String firstNonEmpty(
			JSONObject object,
			String... keys) {

		if (object == null
				|| keys == null) {

			return "";
		}

		for (String key : keys) {

			String value =
					object.optString(
							key,
							""
					).trim();

			if (value.length() == 0
					|| value.equalsIgnoreCase(
							"null"
					)) {

				continue;
			}

			return fixImageUrl(value);
		}

		return "";
	}

	private static String fixImageUrl(
			String url) {

		if (url == null) {
			return "";
		}

		String fixed =
				url.trim();

		if (fixed.length() == 0
				|| fixed.equalsIgnoreCase(
						"null"
				)) {

			return "";
		}

		if (fixed.startsWith("//")) {

			return "https:" + fixed;
		}

		return fixed;
	}
}