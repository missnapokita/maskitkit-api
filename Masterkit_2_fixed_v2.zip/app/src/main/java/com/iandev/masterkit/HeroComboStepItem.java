package com.iandev.masterkit;

public class HeroComboStepItem {

	public int step = 0;
	public String label = "";
	public String image = "";
}
