package com.iandev.masterkit;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;

import androidx.viewpager2.widget.ViewPager2;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class BannerSlider {

	private static final int MAX_DOTS = 5;
	private static final long AUTO_SLIDE_DELAY = 4000L;

	private static String suggestedJson = "";
	private static String heroMetaJson = "";

	private static BannerSlider currentInstance;

	private final Activity activity;
	private final View rootView;

	private final ViewPager2 viewPager;
	private final LinearLayout dotsLayout;

	private final ArrayList<BannerItem> bannerList =
			new ArrayList<BannerItem>();

	private final Handler handler =
			new Handler(Looper.getMainLooper());

	private Runnable autoSlideRunnable;

	private ViewPager2.OnPageChangeCallback pageCallback;

	private BannerSlider(
			Activity activity,
			View rootView) {

		this.activity = activity;
		this.rootView = rootView;

		viewPager =
				(ViewPager2) rootView.findViewById(
						R.id.viewpager_banner
				);

		dotsLayout =
				(LinearLayout) rootView.findViewById(
						R.id.linear_dots
				);
	}

	/*
	 * SUGGESTED/BANNER JSON
	 *
	 * Fragment usage:
	 *
	 * BannerSlider.setSuggestedData(
	 *     getActivity(),
	 *     getView(),
	 *     response
	 * );
	 */
	public static void setSuggestedData(
			Activity activity,
			View rootView,
			String response) {

		suggestedJson =
				response == null
						? ""
						: response.trim();

		if (!isValid(
				activity,
				rootView
		)) {

			return;
		}

		if (suggestedJson.length() == 0) {
			return;
		}

		renderCurrentData(
				activity,
				rootView
		);
	}

	/*
	 * HERO ICON JSON
	 *
	 * Fragment usage:
	 *
	 * BannerSlider.setHeroMetaData(
	 *     getActivity(),
	 *     getView(),
	 *     response
	 * );
	 */
	public static void setHeroMetaData(
			Activity activity,
			View rootView,
			String response) {

		heroMetaJson =
				response == null
						? ""
						: response.trim();

		if (!isValid(
				activity,
				rootView
		)) {

			return;
		}

		/*
		 * Hindi muna magre-render kapag wala pa ang
		 * suggested/banner JSON.
		 */
		if (suggestedJson.length() == 0) {
			return;
		}

		renderCurrentData(
				activity,
				rootView
		);
	}

	private static boolean isValid(
			Activity activity,
			View rootView) {

		if (activity == null
				|| rootView == null) {

			return false;
		}

		if (activity.isFinishing()) {
			return false;
		}

		return true;
	}

	private static void renderCurrentData(
			Activity activity,
			View rootView) {

		if (!isValid(
				activity,
				rootView
		)) {

			return;
		}

		if (currentInstance != null) {
			currentInstance.releaseInternal();
		}

		currentInstance =
				new BannerSlider(
						activity,
						rootView
				);

		currentInstance.render(
				suggestedJson,
				heroMetaJson
		);
	}

	private void render(
			String suggestedResponse,
			String metaResponse) {

		if (viewPager == null
				|| dotsLayout == null) {

			return;
		}

		if (suggestedResponse == null
				|| suggestedResponse.trim().length() == 0) {

			clearSlider();
			return;
		}

		try {

			HashMap<String, String> heroIcons =
					new HashMap<String, String>();

			/*
			 * Optional lang ang hero metadata.
			 * Lalabas agad ang banners kahit hindi pa
			 * dumating o pumalya ang icon JSON.
			 */
			if (metaResponse != null
					&& metaResponse.trim().length() > 0) {

				try {

					heroIcons =
							parseHeroIcons(
									metaResponse
							);

				} catch (Exception ignored) {

					heroIcons =
							new HashMap<String, String>();
				}
			}

			JSONArray suggestedArray =
					new JSONArray(
							suggestedResponse.trim()
					);

			bannerList.clear();

			for (int i = 0;
				 i < suggestedArray.length();
				 i++) {

				JSONObject object =
						suggestedArray.optJSONObject(i);

				if (object == null) {
					continue;
				}

				String image =
						object.optString(
								"image",
								""
						).trim();

				String heroName =
						object.optString(
								"hero_name",
								""
						).trim();

				String skinName =
						object.optString(
								"skin_name",
								""
						).trim();

				if (image.length() == 0) {
					continue;
				}

				BannerItem item =
						new BannerItem();

				item.image = image;
				item.hero_name = heroName;
				item.skin_name = skinName;

				String portrait = "";

				/*
				 * Subukang hanapin muna ang icon
				 * sa hero metadata gamit ang hero name.
				 */
				if (heroName.length() > 0) {

					portrait =
							heroIcons.get(
									normalize(heroName)
							);
				}

				/*
				 * Fallback sa head field ng suggested JSON.
				 *
				 * Kapag tinanggal mo ang "head",
				 * magiging empty lang ito at placeholder
				 * ang ipapakita ng BannerAdapter.
				 */
				if (portrait == null
						|| portrait.trim().length() == 0) {

					portrait =
							object.optString(
									"head",
									""
							).trim();
				}

				item.icon =
						portrait == null
								? ""
								: portrait.trim();

				bannerList.add(item);
			}

			if (bannerList.isEmpty()) {

				clearSlider();
				return;
			}

			BannerAdapter adapter =
					new BannerAdapter(
							activity,
							bannerList
					);

			viewPager.setAdapter(adapter);

			viewPager.setOffscreenPageLimit(
					Math.min(
							2,
							bannerList.size()
					)
			);

			viewPager.setCurrentItem(
					0,
					false
			);

			createDots();
			updateDots(0);

			setupPageListener();
			startAutoSlide();

		} catch (Exception error) {

			error.printStackTrace();
			clearSlider();
		}
	}

	private void clearSlider() {

		stopAutoSlide();

		bannerList.clear();

		if (dotsLayout != null) {
			dotsLayout.removeAllViews();
			dotsLayout.setVisibility(View.GONE);
		}

		if (viewPager != null) {
			viewPager.setAdapter(null);
		}
	}

	/*
	 * Compatible sa dalawang JSON format:
	 *
	 * MAPI:
	 * {
	 *     "name": "Bane",
	 *     "key": "//domain/icon.png"
	 * }
	 *
	 * Old metadata:
	 * {
	 *     "hero_name": "Bane",
	 *     "portrait": "https://domain/icon.png"
	 * }
	 */
	private HashMap<String, String> parseHeroIcons(
			String response) throws Exception {

		HashMap<String, String> map =
				new HashMap<String, String>();

		if (response == null
				|| response.trim().length() == 0) {

			return map;
		}

		JSONObject root =
				new JSONObject(
						response.trim()
				);

		JSONArray data =
				root.optJSONArray("data");

		if (data == null) {
			return map;
		}

		for (int i = 0;
			 i < data.length();
			 i++) {

			JSONObject hero =
					data.optJSONObject(i);

			if (hero == null) {
				continue;
			}

			String heroName =
					hero.optString(
							"name",
							""
					).trim();

			if (heroName.length() == 0) {

				heroName =
						hero.optString(
								"hero_name",
								""
						).trim();
			}

			String iconUrl =
					hero.optString(
							"key",
							""
					).trim();

			if (iconUrl.length() == 0) {

				iconUrl =
						hero.optString(
								"portrait",
								""
						).trim();
			}

			if (heroName.length() == 0
					|| iconUrl.length() == 0) {

				continue;
			}

			iconUrl =
					fixUrl(iconUrl);

			if (iconUrl.length() == 0) {
				continue;
			}

			map.put(
					normalize(heroName),
					iconUrl
			);
		}

		return map;
	}

	private static String fixUrl(
			String url) {

		if (url == null) {
			return "";
		}

		String fixed =
				url.trim();

		if (fixed.length() == 0) {
			return "";
		}

		if (fixed.startsWith("//")) {

			fixed =
					"https:" + fixed;

		} else if (!fixed.startsWith("https://")
				&& !fixed.startsWith("http://")) {

			fixed =
					"https://" + fixed;
		}

		return fixed;
	}

	private static String normalize(
			String name) {

		if (name == null) {
			return "";
		}

		return name
				.trim()
				.toLowerCase(Locale.US)
				.replace(".", "")
				.replace("'", "")
				.replace("’", "")
				.replace("-", " ")
				.replace("_", " ")
				.replaceAll("\\s+", " ");
	}

	private void setupPageListener() {

		if (pageCallback != null) {

			try {

				viewPager.unregisterOnPageChangeCallback(
						pageCallback
				);

			} catch (Exception ignored) {
			}
		}

		pageCallback =
				new ViewPager2.OnPageChangeCallback() {

					@Override
					public void onPageSelected(
							int position) {

						super.onPageSelected(position);

						updateDots(position);
						restartAutoSlide();
					}

					@Override
					public void onPageScrollStateChanged(
							int state) {

						super.onPageScrollStateChanged(
								state
						);

						if (state ==
								ViewPager2.SCROLL_STATE_DRAGGING) {

							stopAutoSlide();

						} else if (state ==
								ViewPager2.SCROLL_STATE_IDLE) {

							restartAutoSlide();
						}
					}
				};

		viewPager.registerOnPageChangeCallback(
				pageCallback
		);
	}

	private void startAutoSlide() {

		stopAutoSlide();

		autoSlideRunnable =
				new Runnable() {

					@Override
					public void run() {

						int size =
								bannerList.size();

						if (size <= 1
								|| viewPager == null) {

							return;
						}

						int current =
								viewPager.getCurrentItem();

						int next =
								current + 1;

						if (next >= size) {
							next = 0;
						}

						viewPager.setCurrentItem(
								next,
								true
						);

						handler.postDelayed(
								this,
								AUTO_SLIDE_DELAY
						);
					}
				};

		if (bannerList.size() > 1) {

			handler.postDelayed(
					autoSlideRunnable,
					AUTO_SLIDE_DELAY
			);
		}
	}

	private void restartAutoSlide() {

		if (autoSlideRunnable == null
				|| bannerList.size() <= 1) {

			return;
		}

		handler.removeCallbacks(
				autoSlideRunnable
		);

		handler.postDelayed(
				autoSlideRunnable,
				AUTO_SLIDE_DELAY
		);
	}

	private void stopAutoSlide() {

		if (autoSlideRunnable != null) {

			handler.removeCallbacks(
					autoSlideRunnable
			);
		}
	}

	/*
	 * Maximum 5 dots lang kahit mas marami
	 * ang banner items.
	 */
	private void createDots() {

		if (dotsLayout == null) {
			return;
		}

		dotsLayout.removeAllViews();
		dotsLayout.setGravity(Gravity.CENTER);

		int dotCount =
				Math.min(
						MAX_DOTS,
						bannerList.size()
				);

		for (int i = 0;
			 i < dotCount;
			 i++) {

			View dot =
					new View(
							activity
					);

			LinearLayout.LayoutParams params =
					new LinearLayout.LayoutParams(
							dp(7),
							dp(7)
					);

			params.setMargins(
					dp(4),
					0,
					dp(4),
					0
			);

			dot.setLayoutParams(params);

			dot.setBackground(
					createDotDrawable(false)
			);

			dotsLayout.addView(dot);
		}

		if (bannerList.size() <= 1) {

			dotsLayout.setVisibility(
					View.GONE
			);

		} else {

			dotsLayout.setVisibility(
					View.VISIBLE
			);
		}
	}

	private void updateDots(
			int selectedPosition) {

		if (dotsLayout == null) {
			return;
		}

		int dotCount =
				dotsLayout.getChildCount();

		if (dotCount == 0) {
			return;
		}

		int activeIndex;

		if (bannerList.size() <= dotCount) {

			activeIndex =
					Math.min(
							selectedPosition,
							dotCount - 1
					);

		} else {

			/*
			 * Limang dots lang kahit mas marami ang
			 * slides. Iikot ang active dot.
			 */
			activeIndex =
					selectedPosition % dotCount;
		}

		for (int i = 0;
			 i < dotCount;
			 i++) {

			View dot =
					dotsLayout.getChildAt(i);

			boolean active =
					i == activeIndex;

			LinearLayout.LayoutParams params =
					(LinearLayout.LayoutParams)
							dot.getLayoutParams();

			params.width =
					active
							? dp(18)
							: dp(7);

			params.height =
					dp(7);

			params.setMargins(
					dp(4),
					0,
					dp(4),
					0
			);

			dot.setLayoutParams(params);

			dot.setBackground(
					createDotDrawable(
							active
					)
			);
		}
	}

	private GradientDrawable createDotDrawable(
			boolean selected) {

		GradientDrawable drawable =
				new GradientDrawable();

		drawable.setShape(
				GradientDrawable.RECTANGLE
		);

		drawable.setCornerRadius(
				dp(20)
		);

		drawable.setColor(
				selected
						? Color.parseColor(
								"#FFA31A"
						)
						: Color.parseColor(
								"#66FFFFFF"
						)
		);

		return drawable;
	}

	private int dp(
			int value) {

		float density =
				activity
						.getResources()
						.getDisplayMetrics()
						.density;

		return (int) (
				value * density + 0.5f
		);
	}

	/*
	 * Tawagin ito sa Fragment onDestroyView
	 * para huminto ang auto-slide at maiwasan
	 * ang callbacks sa lumang Fragment view.
	 */
	public static void release() {

		if (currentInstance != null) {

			currentInstance.releaseInternal();
			currentInstance = null;
		}
	}

	private void releaseInternal() {

		stopAutoSlide();

		if (pageCallback != null
				&& viewPager != null) {

			try {

				viewPager.unregisterOnPageChangeCallback(
						pageCallback
				);

			} catch (Exception ignored) {
			}
		}

		handler.removeCallbacksAndMessages(null);

		pageCallback = null;
		autoSlideRunnable = null;
	}
}