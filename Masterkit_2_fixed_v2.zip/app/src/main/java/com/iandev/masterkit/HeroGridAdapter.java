package com.iandev.masterkit;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HeroGridAdapter
		extends RecyclerView.Adapter<HeroGridAdapter.Holder> {

	private final Activity activity;
	private final ArrayList<HeroGridItem> list;
	private Typeface productFont;

	public HeroGridAdapter(
			Activity activity,
			ArrayList<HeroGridItem> list) {

		this.activity = activity;
		this.list = list;

		try {
			productFont = Typeface.createFromAsset(
					activity.getAssets(),
					"fonts/product.ttf"
			);
		} catch (Exception firstError) {

			try {
				productFont = Typeface.createFromAsset(
						activity.getAssets(),
						"product.ttf"
				);
			} catch (Exception ignored) {
				productFont = Typeface.DEFAULT;
			}
		}
	}

	@NonNull
	@Override
	public Holder onCreateViewHolder(
			@NonNull ViewGroup parent,
			int viewType) {

		View view = LayoutInflater
				.from(activity)
				.inflate(
						R.layout.hero_grid_item,
						parent,
						false
				);

		return new Holder(view);
	}

	@Override
	public void onBindViewHolder(
			@NonNull Holder holder,
			int position) {

		final HeroGridItem item = list.get(position);

		holder.name.setText(
				item.name == null ? "" : item.name
		);

		holder.category.setText(
				formatCategory(item.category)
		);

		holder.name.setTypeface(
				productFont,
				Typeface.BOLD
		);

		holder.category.setTypeface(
				productFont,
				Typeface.NORMAL
		);

		SimpleImageLoader.load(
				item.image,
				holder.image,
				R.drawable.des
		);

		holder.itemView.setOnClickListener(
	new View.OnClickListener() {

		@Override
		public void onClick(View view) {

			Intent intent = new Intent(
					activity,
					HeroguideActivity.class
			);

			intent.putExtra(
					"hero_id",
					item.id
			);

			intent.putExtra(
					"hero_name",
					item.name
			);

			activity.startActivity(intent);
		}
	}
);
	}

	private String formatCategory(String category) {

		if (category == null
				|| category.trim().length() == 0) {

			return "Hero";
		}

		String value = category.trim();

		return value.substring(0, 1).toUpperCase()
				+ value.substring(1).toLowerCase();
	}

	@Override
	public int getItemCount() {
		return list == null ? 0 : list.size();
	}

	public static class Holder
			extends RecyclerView.ViewHolder {

		ImageView image;
		TextView name;
		TextView category;

		public Holder(View itemView) {
			super(itemView);

			image = itemView.findViewById(
					R.id.imageview_hero
			);

			name = itemView.findViewById(
					R.id.textview_hero_name
			);

			category = itemView.findViewById(
					R.id.textview_hero_category
			);
		}
	}
}