package com.iandev.masterkit;

import java.util.HashMap;
import java.util.Locale;

public final class HeroImageRegistry {
	private static final HashMap<String, String> MAP = new HashMap<>();
	private HeroImageRegistry() {}
	public static synchronized void put(String id, String image) {
		if (id == null || image == null) return;
		id = id.trim().toLowerCase(Locale.US);
		image = image.trim();
		if (!id.isEmpty() && !image.isEmpty()) MAP.put(id, image);
	}
	public static synchronized String get(String id, String fallback) {
		if (id == null) return fallback == null ? "" : fallback;
		String value = MAP.get(id.trim().toLowerCase(Locale.US));
		return value == null || value.trim().isEmpty() ? (fallback == null ? "" : fallback) : value;
	}
}
