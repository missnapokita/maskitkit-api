package com.iandev.masterkit;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class MainPagerAdapter extends FragmentPagerAdapter {

	public MainPagerAdapter(FragmentManager fragmentManager) {
		super(
				fragmentManager,
				FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
		);
	}

	@NonNull
	@Override
	public Fragment getItem(int position) {

		switch (position) {

			case 1:
				return new MenuFragment();

			case 2:
				return new SettingsFragment();

			case 0:
			default:
				return new Home1Fragment();
		}
	}

	@Override
	public int getCount() {
		return 3;
	}

	@Override
	public CharSequence getPageTitle(int position) {

		switch (position) {

			case 1:
				return "Menu";

			case 2:
				return "Settings";

			case 0:
			default:
				return "Home";
		}
	}
}