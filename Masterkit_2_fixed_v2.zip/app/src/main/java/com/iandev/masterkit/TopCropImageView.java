package com.iandev.masterkit;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatImageView;

/**
 * ImageView equivalent of CENTER_CROP, but vertically aligned to the TOP.
 *
 * Ideal for 9:16 hero skin artwork displayed inside a wide banner.
 */
public class TopCropImageView extends AppCompatImageView {

	private final Matrix topCropMatrix =
			new Matrix();

	public TopCropImageView(Context context) {
		super(context);
		initialize();
	}

	public TopCropImageView(
			Context context,
			AttributeSet attrs) {

		super(context, attrs);
		initialize();
	}

	public TopCropImageView(
			Context context,
			AttributeSet attrs,
			int defStyleAttr) {

		super(context, attrs, defStyleAttr);
		initialize();
	}

	private void initialize() {
		super.setScaleType(ScaleType.MATRIX);
	}

	@Override
	public void setScaleType(
			ScaleType scaleType) {

		/*
		 * Keep MATRIX so XML or image loaders cannot switch this
		 * back to CENTER_CROP.
		 */
		super.setScaleType(ScaleType.MATRIX);
		updateTopCropMatrix();
	}

	@Override
	protected boolean setFrame(
			int left,
			int top,
			int right,
			int bottom) {

		boolean changed =
				super.setFrame(
						left,
						top,
						right,
						bottom
				);

		updateTopCropMatrix();
		return changed;
	}

	@Override
	public void setImageDrawable(
			Drawable drawable) {

		super.setImageDrawable(drawable);
		updateTopCropMatrix();
	}

	private void updateTopCropMatrix() {

		Drawable drawable =
				getDrawable();

		if (drawable == null) {
			return;
		}

		int drawableWidth =
				drawable.getIntrinsicWidth();

		int drawableHeight =
				drawable.getIntrinsicHeight();

		int viewWidth =
				getWidth() - getPaddingLeft()
						- getPaddingRight();

		int viewHeight =
				getHeight() - getPaddingTop()
						- getPaddingBottom();

		if (drawableWidth <= 0
				|| drawableHeight <= 0
				|| viewWidth <= 0
				|| viewHeight <= 0) {
			return;
		}

		float scale =
				Math.max(
						(float) viewWidth
								/ drawableWidth,
						(float) viewHeight
								/ drawableHeight
				);

		float scaledWidth =
				drawableWidth * scale;

		float translateX =
				(viewWidth - scaledWidth) * 0.5f;

		/*
		 * Top aligned: no vertical centering.
		 */
		float translateY = 0f;

		topCropMatrix.reset();

		topCropMatrix.setScale(
				scale,
				scale
		);

		topCropMatrix.postTranslate(
				translateX + getPaddingLeft(),
				translateY + getPaddingTop()
		);

		setImageMatrix(topCropMatrix);
	}
}
