package com.iandev.masterkit;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HeroBuildAdapter
		extends RecyclerView.Adapter<HeroBuildAdapter.Holder> {

	private final Activity activity;
	private final ArrayList<HeroBuildItem> list;

	public HeroBuildAdapter(
			Activity activity,
			ArrayList<HeroBuildItem> list) {

		this.activity = activity;
		this.list = list;
	}

	@NonNull
	@Override
	public Holder onCreateViewHolder(
			@NonNull ViewGroup parent,
			int viewType) {

		View view = LayoutInflater
				.from(activity)
				.inflate(
						R.layout.hero_build_item,
						parent,
						false
				);

		return new Holder(view);
	}

	@Override
	public void onBindViewHolder(
			@NonNull Holder holder,
			int position) {

		HeroBuildItem item = list.get(position);

		holder.name.setText(
				item.name == null
						? ""
						: item.name
		);

		if (item.image == null || item.image.trim().isEmpty()) {
			holder.image.setImageResource(R.drawable.des);
		} else {
			SimpleImageLoader.load(
					item.image,
					holder.image,
					R.drawable.des
			);
		}
	}

	@Override
	public int getItemCount() {
		return list == null ? 0 : list.size();
	}

	public static class Holder
			extends RecyclerView.ViewHolder {

		ImageView image;
		TextView name;

		public Holder(View itemView) {
			super(itemView);

			image = itemView.findViewById(
					R.id.imageview_item
			);

			name = itemView.findViewById(
					R.id.textview_item
			);
		}
	}
}