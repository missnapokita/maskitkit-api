package com.iandev.masterkit;

public class BannerItem {

	public String image = "";
	public String hero_name = "";
	public String skin_name = "";
	public String icon = "";

}