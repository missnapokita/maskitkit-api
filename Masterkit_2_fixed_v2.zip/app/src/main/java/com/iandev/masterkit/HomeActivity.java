package com.iandev.masterkit;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.bumptech.glide.*;
import com.iandev.masterkit.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class HomeActivity extends AppCompatActivity {
	
	private HomeBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = HomeBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		final androidx.viewpager.widget.ViewPager mainPager =
		(androidx.viewpager.widget.ViewPager)
		findViewById(R.id.viewpager_main);
		
		if (mainPager != null) {
			
			MainPagerAdapter pagerAdapter =
			new MainPagerAdapter(
			getSupportFragmentManager()
			);
			
			mainPager.setAdapter(pagerAdapter);
			
			// Panatilihing buhay ang tatlong pages.
			mainPager.setOffscreenPageLimit(3);
			
			// Default page: Home.
			mainPager.setCurrentItem(0, false);
			
			// Ikabit ang Home / Menu / Settings navbar.
			MasterkitNavigation.setup(HomeActivity.this);
		}
		_NavStatusBarColor("#0D0D0D", "#212121");
		binding.textviewNavHome.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/product.ttf"), 0);
		binding.textviewNavMenu.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/product.ttf"), 0);
		binding.textviewNavSettings.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/product.ttf"), 0);
	}
	
	public void _Ui() {
		// FULLSCREEN + TRANSPARENT STATUS BAR
		if (android.os.Build.VERSION.SDK_INT >= 21) {
			
			getWindow().setStatusBarColor(
			android.graphics.Color.TRANSPARENT
			);
			
			getWindow().setNavigationBarColor(
			android.graphics.Color.parseColor("#0D0D0D")
			);
			
			getWindow().getDecorView().setSystemUiVisibility(
			android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			| android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			| android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			);
			
		} else {
			
			getWindow().setFlags(
			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN
			);
		}
		if (android.os.Build.VERSION.SDK_INT >= 30) {
			
			getWindow().setDecorFitsSystemWindows(false);
			
			final android.view.WindowInsetsController controller =
			getWindow().getInsetsController();
			
			if (controller != null) {
				
				controller.setSystemBarsAppearance(
				0,
				android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
				);
			}
		}
	}
	
	
	public void _NavStatusBarColor(final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
}