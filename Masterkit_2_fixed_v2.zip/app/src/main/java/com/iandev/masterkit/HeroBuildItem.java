package com.iandev.masterkit;

public class HeroBuildItem {

	public String name = "";
	public String image = "";

}