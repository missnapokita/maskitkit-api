package com.iandev.masterkit;

import android.app.Activity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Locale;

/**
 * Local equipment image resolver backed by assets/items.json.
 * No API request is required to discover the item image URL.
 */
public final class LocalItemImageResolver {

	private static final HashMap<String, String> IMAGES =
			new HashMap<>();

	private static boolean loaded;

	private LocalItemImageResolver() {
	}

	public static String getImage(
			Activity activity,
			String itemName) {

		if (activity == null) {
			return "";
		}

		ensureLoaded(activity);

		String key =
				normalize(itemName);

		if (key.isEmpty()) {
			return "";
		}

		String direct =
				IMAGES.get(key);

		if (direct != null && !direct.isEmpty()) {
			return direct;
		}

		for (String storedKey : IMAGES.keySet()) {

			if (storedKey.equals(key)
					|| storedKey.contains(key)
					|| key.contains(storedKey)) {

				String image =
						IMAGES.get(storedKey);

				if (image != null && !image.isEmpty()) {
					return image;
				}
			}
		}

		return "";
	}

	private static synchronized void ensureLoaded(
			Activity activity) {

		if (loaded) {
			return;
		}

		loaded = true;

		try {
			InputStream inputStream =
					activity.getAssets()
							.open("items.json");

			JSONObject root =
					new JSONObject(
							readStream(inputStream)
					);

			JSONArray data =
					root.optJSONArray("data");

			if (data == null) {
				return;
			}

			for (int i = 0; i < data.length(); i++) {

				JSONObject item =
						data.optJSONObject(i);

				if (item == null) {
					continue;
				}

				String name =
						item.optString("name", "");

				String image =
						item.optString("image", "");

				String key =
						normalize(name);

				if (!key.isEmpty() && isHttp(image)) {
					IMAGES.put(key, image.trim());
				}
			}

		} catch (Exception ignored) {
		}
	}

	private static String readStream(
			InputStream inputStream)
			throws Exception {

		BufferedReader reader =
				new BufferedReader(
						new InputStreamReader(
								inputStream,
								"UTF-8"
						)
				);

		StringBuilder result =
				new StringBuilder();

		String line;

		while ((line = reader.readLine()) != null) {
			result.append(line);
		}

		reader.close();

		return result.toString();
	}

	private static boolean isHttp(
			String value) {

		String clean =
				value == null
						? ""
						: value.trim().toLowerCase(Locale.US);

		return clean.startsWith("https://")
				|| clean.startsWith("http://");
	}

	private static String normalize(
			String value) {

		return value == null
				? ""
				: value.toLowerCase(Locale.US)
						.replace("&", "and")
						.replace("’", "")
						.replace("'", "")
						.replace("-", "")
						.replace("_", "")
						.replace(" ", "")
						.trim();
	}
}
