MASTERKIT MLBB IMAGE PATCH

FILES
- HeroGuideLoader.java

WHAT IT DOES
1. Keeps the current MasterKit API as the primary source.
2. Downloads the p3hndrx MLBB hero dataset as a secondary source.
3. Finds the matching hero using the hero name first and numeric ID second.
4. Replaces the banner image/backdrop with the MLBB portrait URL.
5. Adds/fixes skill image URLs, cooldown, mana cost, type and descriptions.
6. Falls back to the current MasterKit data when the MLBB source is unavailable.
7. Caches the downloaded MLBB JSON in memory so it is not downloaded again
   while the app process is still running.

INSTALL
Replace your current:
  com/iandev/masterkit/HeroGuideLoader.java

with the included file.

NO XML CHANGES REQUIRED for the banner replacement.

IMPORTANT
- Your skill adapter must read one of these image keys:
    image
    icon
    skill_icon
  The patched loader provides all three keys.
- The repository data is MIT licensed, but Mobile Legends names/art are still
  third-party game assets. Keep your app clearly unofficial/fan-made.
- The secondary hero JSON is around 748 KB. For best production performance,
  later mirror a simplified converted JSON to your own GitHub/Vercel endpoint.

DATA SOURCES
Primary:
https://maskitkit-api.vercel.app/api/hero?id={heroId}

Secondary:
https://raw.githubusercontent.com/p3hndrx/MLBB-API/refs/heads/main/v1/hero-meta-final.json
