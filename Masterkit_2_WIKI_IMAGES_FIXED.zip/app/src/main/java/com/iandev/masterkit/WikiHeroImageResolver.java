package com.iandev.masterkit;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Locale;

/**
 * Loads consistent hero icons from MLBB Wiki API.
 * The complete hero list is downloaded only once per app process.
 */
public final class WikiHeroImageResolver {

    private static final String HEROES_URL =
            "https://mlbb-wiki-api.vercel.app/api/heroes";

    private static final HashMap<String, String> ICONS = new HashMap<>();
    private static boolean loaded = false;

    private WikiHeroImageResolver() {
    }

    public static synchronized String getCached(String heroName) {
        String key = normalize(heroName);
        String value = ICONS.get(key);
        return value == null ? "" : value;
    }

    public static String getIconBlocking(String heroName) {
        String key = normalize(heroName);
        if (key.isEmpty()) return "";

        synchronized (WikiHeroImageResolver.class) {
            String cached = ICONS.get(key);
            if (cached != null && !cached.isEmpty()) return cached;

            if (!loaded) {
                loadAllIcons();
            }

            cached = ICONS.get(key);
            return cached == null ? "" : cached;
        }
    }

    private static void loadAllIcons() {
        HttpURLConnection connection = null;
        InputStream stream = null;
        BufferedReader reader = null;

        try {
            URL url = new URL(HEROES_URL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setUseCaches(true);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "MasterKit-Android");

            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return;

            stream = connection.getInputStream();
            reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));

            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line);

            JSONObject root = new JSONObject(body.toString());
            JSONArray data = root.optJSONArray("data");
            if (data == null) return;

            for (int i = 0; i < data.length(); i++) {
                JSONObject hero = data.optJSONObject(i);
                if (hero == null) continue;

                String name = hero.optString("hero_name", "").trim();
                String icon = hero.optString("icon", "").trim();

                if (!name.isEmpty() && isHttp(icon)) {
                    ICONS.put(normalize(name), optimizeWikiUrl(icon));
                }
            }

            loaded = !ICONS.isEmpty();

        } catch (Exception ignored) {
            // Existing MasterKit images remain as fallback.
        } finally {
            try { if (reader != null) reader.close(); } catch (Exception ignored) {}
            try { if (stream != null) stream.close(); } catch (Exception ignored) {}
            if (connection != null) connection.disconnect();
        }
    }

    private static String optimizeWikiUrl(String url) {
        String clean = url == null ? "" : url.trim();
        if (clean.isEmpty()) return "";

        // Wikia accepts revision/latest and a requested width.
        if (!clean.contains("/revision/latest")) {
            int query = clean.indexOf('?');
            if (query >= 0) clean = clean.substring(0, query);
            clean = clean + "/revision/latest";
        }

        if (!clean.contains("?")) {
            clean = clean + "?cb=1&format=original";
        }

        return clean;
    }

    private static boolean isHttp(String value) {
        String clean = value == null ? "" : value.trim().toLowerCase(Locale.US);
        return clean.startsWith("https://") || clean.startsWith("http://");
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return value.trim()
                .toLowerCase(Locale.US)
                .replace("&", "and")
                .replace("’", "")
                .replace("'", "")
                .replace(".", "")
                .replace("-", "")
                .replace("_", "")
                .replace(" ", "");
    }
}
