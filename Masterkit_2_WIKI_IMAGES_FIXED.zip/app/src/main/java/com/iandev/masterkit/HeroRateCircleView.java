package com.iandev.masterkit;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import java.util.Locale;

public class HeroRateCircleView extends View {

	private final Paint backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final RectF arcBounds = new RectF();

	private float value = 0f;
	private float shownValue = 0f;
	private String label = "";
	private int progressColor = 0xFFFFB300;

	public HeroRateCircleView(Context context) {
		super(context);
		init();
	}

	public HeroRateCircleView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public HeroRateCircleView(
			Context context,
			AttributeSet attrs,
			int defStyleAttr) {

		super(context, attrs, defStyleAttr);
		init();
	}

	private void init() {

		float density =
				getResources()
						.getDisplayMetrics()
						.density;

		backgroundPaint.setStyle(Paint.Style.STROKE);
		backgroundPaint.setStrokeCap(Paint.Cap.ROUND);
		backgroundPaint.setStrokeWidth(5f * density);
		backgroundPaint.setColor(0xFF303030);

		progressPaint.setStyle(Paint.Style.STROKE);
		progressPaint.setStrokeCap(Paint.Cap.ROUND);
		progressPaint.setStrokeWidth(5f * density);
		progressPaint.setColor(progressColor);

		valuePaint.setTextAlign(Paint.Align.CENTER);
		valuePaint.setColor(0xFFFFFFFF);
		valuePaint.setFakeBoldText(true);
		valuePaint.setTextSize(15f * density);

		labelPaint.setTextAlign(Paint.Align.CENTER);
		labelPaint.setColor(0xFF8A8A8A);
		labelPaint.setFakeBoldText(true);
		labelPaint.setTextSize(8.5f * density);

		setLayerType(View.LAYER_TYPE_SOFTWARE, null);
	}

	public void setData(
			double percent,
			String label,
			int color,
			boolean animate) {

		float next = (float) percent;

		if (Float.isNaN(next)
				|| Float.isInfinite(next)) {
			next = 0f;
		}

		this.value = Math.max(
				0f,
				Math.min(100f, next)
		);

		this.label =
				label == null ? "" : label;

		this.progressColor = color;
		progressPaint.setColor(color);

		if (!animate) {
			shownValue = this.value;
			invalidate();
			return;
		}

		ValueAnimator animator =
				ValueAnimator.ofFloat(
						shownValue,
						this.value
				);

		animator.setDuration(650L);

		animator.addUpdateListener(
				new ValueAnimator.AnimatorUpdateListener() {
					@Override
					public void onAnimationUpdate(
							ValueAnimator valueAnimator) {

						shownValue =
								(Float)
										valueAnimator
												.getAnimatedValue();

						invalidate();
					}
				}
		);

		animator.start();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		float density =
				getResources()
						.getDisplayMetrics()
						.density;

		float centerX = getWidth() / 2f;
		float circleTop = 6f * density;
		float radius =
				Math.min(
						getWidth() * 0.34f,
						getHeight() * 0.30f
				);

		float centerY =
				circleTop + radius;

		float inset = 4f * density;

		arcBounds.set(
				centerX - radius + inset,
				centerY - radius + inset,
				centerX + radius - inset,
				centerY + radius - inset
		);

		canvas.drawArc(
				arcBounds,
				-90f,
				360f,
				false,
				backgroundPaint
		);

		canvas.drawArc(
				arcBounds,
				-90f,
				360f * shownValue / 100f,
				false,
				progressPaint
		);

		String percentText =
				format(shownValue) + "%";

		Paint.FontMetrics valueMetrics =
				valuePaint.getFontMetrics();

		float valueY =
				centerY -
				(valueMetrics.ascent +
				valueMetrics.descent) / 2f;

		canvas.drawText(
				percentText,
				centerX,
				valueY,
				valuePaint
		);

		float labelY =
				Math.min(
						getHeight() - 5f * density,
						centerY + radius + 18f * density
				);

		canvas.drawText(
				label,
				centerX,
				labelY,
				labelPaint
		);
	}

	private String format(float number) {

		if (Math.abs(number - Math.round(number)) < 0.05f) {
			return String.valueOf(Math.round(number));
		}

		return String.format(
				Locale.US,
				"%.1f",
				number
		);
	}
}
